import React, { useContext } from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Header from "./components/Hearder";
import CreateThoiGianDiemDanh from "./components/quanlythoigian/CreateThoiGianDiemDanh";
import ThoiGianDiemDanhList from "./components/quanlythoigian/ThoiGianDiemDanhList";
import UpdateForm from "./components/quanlythoigian/UpdateForm";
import AddQr from "./components/quanlyQR/AddQr";
import ListQr from "./components/quanlyQR/ListQr";
import FormQr from "./components/quanlyQR/FormQr";
import AddImagenv from "./components/QuanLyimage_nv/AddImagenv";
import ListImagenv from "./components/QuanLyimage_nv/ListImagenv";
import FormImage from "./components/QuanLyimage_nv/FormImage";
import AddTK from "./components/Quanlytaikhoan/AddTK";
import XoaTK from "./components/Quanlytaikhoan/XoaTK";
import TimKiem from "./components/Quanlytaikhoan/TimKiem";
import LoginAdmin from "./components/Admin/LoginAdmin";
import Profile from "./components/Admin/Profile";
import Them from "./components/Quanlytaikhoan/Them";
import { Context } from "./components/Admin/Context";
import MonthlyAttendance from "./components/thongke/MonthlyAttendance";
import AllMonth from "./components/thongke/AllMonth";
import NgayNghi from "./components/thongke/NgayNghi";
import ThongKe from './components/QLNgay/ThongKe';
import LayNgay from './components/QLNgay/LayNgay';
import ALL from './components/Quanlytaikhoan/ALL';



function App() {
  const { state } = useContext(Context);
  const { isLoggedIn } = state;
  console.log(isLoggedIn);

  // useEffect(() => {
  //   if (!isLoggedIn) {
  //     window.location.href = '/log'; // Chuyển hướng trực tiếp qua URL
  //   }
  // }, [isLoggedIn]);

  return (
    <BrowserRouter>
      <div className="flex flex-col sm:flex-row">
        <Header isLoggedIn={isLoggedIn} />
        <main className="flex-1 m-4 p-2">
          <Routes>
            <Route index element={<LoginAdmin />} />
            <Route path="/create" element={<CreateThoiGianDiemDanh />} />
            <Route path="/list" element={<ThoiGianDiemDanhList />} />
            <Route path="/update/:id" element={<UpdateForm />} />
            <Route path="/addqr" element={<AddQr />} />
            <Route path="/listqr" element={<ListQr />} />
            <Route path="/updateqr/:id" element={<FormQr />} />
            <Route path="/addimage" element={<AddImagenv />} />
            <Route path="/listimage" element={<ListImagenv />} />
            <Route path="/updateimage/:id" element={<FormImage />} />
            <Route path="/edit" element={<AddTK />} />
            <Route path="/seach" element={<TimKiem />} />
            <Route path="/delete" element={<XoaTK />} />
            <Route path="/log" element={<LoginAdmin />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/add" element={<Them />} />


            <Route path="/up" element={<AddTK />} />
            <Route path="/edit/:id" element={<AddTK />} />
            <Route path="/edil" element={<ALL />} />
            <Route path="/sta" element={<ThongKe />} />
            <Route path="/atten" element={<LayNgay />} />
            <Route path="/delete/:id" element={<XoaTK />} />




            <Route path="/thongkethangnam" element={<MonthlyAttendance />} />
            <Route path="/thongketatca" element={<AllMonth />} />
            <Route path="/thongkengaynghi" element={<NgayNghi />} />
            <Route
              path="/pro4"
              element={isLoggedIn ? <Profile /> : <Navigate to="/log" />}
            />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  );
}
export default App;
