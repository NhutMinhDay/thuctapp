import React, { useContext } from "react";
import { Navigate } from "react-router-dom";
import { Context } from "./Context";

const LoginAdmin = () => {
  const { state, dispatch, login } = useContext(Context); // Đã loại bỏ 'login'

  const { user, MK, loading, error, isLoggedIn } = state;

  const handleSubmit = async (e) => {
    e.preventDefault();
    login(user, MK);
  };
  const handleChange = (e) => {
    dispatch({
      type: "FIELD",
      fieldName: e.target.name,
      payload: e.target.value,
    });
  };

  if (isLoggedIn) {
    return <Navigate to="/profile" />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-400 to-pink-400 flex items-center justify-center font-semibold">
      <form
        onSubmit={handleSubmit}
        className="bg-slate-200 rounded-lg shadow-lg p-8 w-96"
      >
        <div className="mb-5">
          <label htmlFor="username" className="block text-lg text-gray-800">
            Tên đăng nhập:
          </label>
          <input
            type="text"
            name="user"
            id="user"
            value={user}
            onChange={handleChange}
            className="my-3 p-3 w-full rounded-md border-gray-800 shadow-lg focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
          />
        </div>
        <div className="mb-5">
          <label htmlFor="password" className="block text-lg text-gray-800">
            Mật khẩu:
          </label>
          <input
            type="password"
            name="MK"
            id="MK"
            value={MK}
            onChange={handleChange}
            className="my-3 p-3 w-full rounded-md border-gray-800 shadow-lg focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
          />
        </div>
        {error && <p className="text-red-500">{error}</p>}
        <button
          type="submit"
          disabled={loading}
          className="w-full bg-gradient-to-r from-red-600 to-pink-600 text-white rounded-md px-4 py-2 mt-4 disabled:bg-gray-400 disabled:cursor-not-allowed"
        >
          {loading ? "Đang đăng nhập..." : "Đăng nhập"}
        </button>
      </form>
    </div>
  );
};

export default LoginAdmin;