// ThoiGianDiemDanhList.js
import React, { useEffect, useState } from "react";
import axios from "axios";
import UpdateForm from "./UpdateForm";
import CreateThoiGianDiemDanh from "./CreateThoiGianDiemDanh";

const ThoiGianDiemDanhList = () => {
  const [entries, setEntries] = useState([]);
  const [selectedEntry, setSelectedEntry] = useState(null);
  useEffect(() => {
    const fetchEntries = async () => {
      try {
        const response = await axios.get("/api/thoigian_diemdanh");
        setEntries(response.data);
      } catch (error) {
        console.error("Error fetching entries:", error);
      }
    };
    fetchEntries();
  }, []);

  const handleDelete = async (id) => {
    try {
      await axios.delete(`/api/thoigian_diemdanh/${id}`);
      setEntries(entries.filter((entry) => entry.ID_TGDD !== id));
      console.log("Entry deleted successfully");
    } catch (error) {
      console.error("Error deleting entry:", error);
    }
  };

  const handleUpdate = async (id) => {
    // Lấy thông tin mục cần cập nhật từ danh sách
    const entryToUpdate = entries.find((entry) => entry.ID_TGDD === id);
    setSelectedEntry(entryToUpdate);
  };

  return (
    <div className="w-auto">
    <h2 className="font-semibold text-center text-2xl p-5">Thời gian điểm danh</h2>
    <div><CreateThoiGianDiemDanh/></div>
    <table className="mx-auto border-collapse border border-gray-500 text-sm">
      <thead>
        <tr>
          <th className="border border-gray-700 p-3">ĐẦU SÁNG</th>
          <th className="border border-gray-700 p-3">CUỐI SÁNG</th>
          <th className="border border-gray-700 p-3">ĐẦU CHIỀU</th>
          <th className="border border-gray-700 p-3">CUỐI CHIỀU</th>
          <th className="border border-gray-700 p-3">HÀNH ĐỘNG</th>
        </tr>
      </thead>
      <tbody>
        {entries.map((entry) => (
          <tr key={entry.ID_TGDD}>
            <td className="border border-gray-700 p-3">{entry.DD_SANGDAU}</td>
            <td className="border border-gray-700 p-3">{entry.DD_SANGCUOI}</td>
            <td className="border border-gray-700 p-3">{entry.DD_CHIEUDAU}</td>
            <td className="border border-gray-700 p-3">{entry.DD_CHIEUCUOI}</td>
            <td className="border border-gray-700 p-3">
              <button className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mr-2" onClick={() => handleUpdate(entry.ID_TGDD)}>
                Update
              </button>
              <button className="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded" onClick={() => handleDelete(entry.ID_TGDD)}>
                Delete
              </button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
    

      {/* Hiển thị form cập nhật nếu selectedEntry được set */}
      {selectedEntry && <UpdateForm entry={selectedEntry} />}
    </div>
  );
};

export default ThoiGianDiemDanhList;
