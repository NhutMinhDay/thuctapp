// UpdateForm.js
import React, { useState } from 'react';
import axios from 'axios';

const UpdateForm = ({ entry }) => {
  const [formData, setFormData] = useState({
    DD_SANGDAU: entry.DD_SANGDAU,
    DD_SANGCUOI: entry.DD_SANGCUOI,
    DD_CHIEUDAU: entry.DD_CHIEUDAU,
    DD_CHIEUCUOI: entry.DD_CHIEUCUOI
  });

  const handleChange = event => {
    const { name, value } = event.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleSubmit = async event => {
    event.preventDefault();
    try {
      await axios.put(`/api/thoigian_diemdanh/${entry.ID_TGDD}`, formData);
      console.log('Update successful');
      // Redirect hoặc thực hiện hành động khác sau khi cập nhật thành công
    } catch (error) {
      console.error('Error updating data:', error);
    }
  };

  return (
    <div>
      <h2>Update Form</h2>
      <form onSubmit={handleSubmit}>
        <label>
          DD_SANGDAU:
          <input type={"datetime-local"} name="DD_SANGDAU" value={formData.DD_SANGDAU} onChange={handleChange} />
        </label>
        <br />
        <label>
          DD_SANGCUOI:
          <input type={"datetime-local"} name="DD_SANGCUOI" value={formData.DD_SANGCUOI} onChange={handleChange} />
        </label>
        <br />
        <label>
          DD_CHIEUDAU:
          <input type={"datetime-local"} name="DD_CHIEUDAU" value={formData.DD_CHIEUDAU} onChange={handleChange} />
        </label>
        <br />
        <label>
          DD_CHIEUCUOI:
          <input type={"datetime-local"} name="DD_CHIEUCUOI" value={formData.DD_CHIEUCUOI} onChange={handleChange} />
        </label>
        <br />
        <button type="submit" className='bg-red-500'>Update</button>
      </form>
    </div>
  );
};

export default UpdateForm;
