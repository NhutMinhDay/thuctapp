// import React, { useState, useEffect } from 'react';
// import axios from 'axios';

// const AttendanceList = () => {
//     const [attendanceData, setAttendanceData] = useState([]);
//     const [successCount, setSuccessCount] = useState(0);
//     const [loading, setLoading] = useState(false);

//     useEffect(() => {
//         fetchAttendanceData();
//         fetchAttendanceSummary(); // Fetch summary data when component mounts
//     }, []);

//     const fetchAttendanceData = async () => {
//         setLoading(true);
//         try {
//             const response = await axios.get('http://localhost:5000/api/thongkengaylam');
//             setAttendanceData(response.data);
//         } catch (error) {
//             console.error('Error fetching attendance data', error);
//         }
//         setLoading(false);
//     };

//     const fetchAttendanceSummary = async () => {
//         setLoading(true);
//         try {
//             const response = await axios.get('http://localhost:5000/api/thongkengaylam1111');
//             setAttendanceData(response.data.entries);
//             setSuccessCount(response.data.success_count); // Set successCount from API response
//         } catch (error) {
//             console.error('Error fetching attendance summary', error);
//         }
//         setLoading(false);
//     };

//     const tableStyle = {
//         borderCollapse: 'collapse',
//         width: '80%',
//         margin: 'auto',
//     };

//     const thStyle = {
//         border: '1px solid black',
//         padding: '8px',
//         backgroundColor: '#8ddc9e',
//         textAlign: 'left',
//     };

//     const tdStyle = {
//         border: '1px solid black',
//         padding: '8px',
//         textAlign: 'left',
//     };

//     const calculateTotalDaysWorked = () => {
//         return attendanceData.reduce((total, record) => {
//             return total + (record.KETQUADIEMDANH === 'thành công' ? 1 : 0);
//         }, 0);
//     };

//     return (
//         <center>
//             <div className="attendance-list">
//                 <h2>Điểm Danh Nhân Viên</h2>
//                 {loading ? (
//                     <p>Loading...</p>
//                 ) : (
//                     <table style={tableStyle}>
//                         <thead>
//                             <tr>
//                                 <th style={thStyle}>ID_NV</th>
//                                 <th style={thStyle}>Thời Gian</th>
//                                 <th style={thStyle}>Trạng Thái</th>
//                             </tr>
//                         </thead>
//                         <tbody>
//                             {attendanceData.map(record => (
//                                 <tr key={record.ID_THONGKE}>
//                                     <td style={tdStyle}>{record.ID_NV}</td>
//                                     <td style={tdStyle}>{new Date(record.THOIGIANDIEMDANH).toLocaleString()}</td>
//                                     <td style={tdStyle}>{record.KETQUADIEMDANH}</td>
//                                 </tr>
//                             ))}
//                         </tbody>
//                     </table>
//                 )}
//             </div>

//             <br />

//             <div>
//                 <h2>Thống Kê Ngày Làm Tổng</h2>
//                 {loading ? (
//                     <p>Loading...</p>
//                 ) : (
//                     <div>
//                         <table style={tableStyle}>
//                             <thead>
//                                 <tr>
//                                     <th style={thStyle}>DiemDanhID</th>
//                                     <th style={thStyle}>ID_NV</th>
//                                     <th style={thStyle}>Ngày Làm</th>
//                                     <th style={thStyle}>Kết Quả Điểm Danh</th>
//                                     <th style={thStyle}>Thời Gian Vào Sáng</th>
//                                     <th style={thStyle}>Thời Gian Ra Sáng</th>
//                                     <th style={thStyle}>Thời Gian Vào Chiều</th>
//                                     <th style={thStyle}>Thời Gian Ra Chiều</th>
//                                 </tr>
//                             </thead>
//                             <tbody>
//                                 {attendanceData.map(record => (
//                                     <tr key={record.DiemDanhID}>
//                                         <td style={tdStyle}>{record.DiemDanhID}</td>
//                                         <td style={tdStyle}>{record.ID_NV}</td>
//                                         <td style={tdStyle}>{record.NgayLam ? new Date(record.NgayLam).toLocaleDateString() : '-'}</td>
//                                         <td style={tdStyle}>{record.KETQUADIEMDANH}</td>
//                                         <td style={tdStyle}>{record.THOIGIAN_VAO_SANG}</td>
//                                         <td style={tdStyle}>{record.THOIGIAN_RA_SANG}</td>
//                                         <td style={tdStyle}>{record.THOIGIAN_VAO_CHIEU}</td>
//                                         <td style={tdStyle}>{record.THOIGIAN_RA_CHIEU}</td>
//                                     </tr>
//                                 ))}
//                             </tbody>
//                         </table>
//                     </div>
//                 )}
//                 {/* <p>Số lần điểm danh thành công: {successCount}</p> */}
//             </div>

//             <div>
//                 <h2>Tổng cộng</h2>
//                 <p>Tổng số ngày làm: {attendanceData.length}</p>
//                 <p>Số ngày điểm danh thành công: {calculateTotalDaysWorked()}</p>
//             </div>
//         </center>
//     );
// };

// export default AttendanceList;





import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from "react-router-dom";

const AttendanceList = () => {
    const [attendanceData, setAttendanceData] = useState([]);
    const [successCount, setSuccessCount] = useState(0);
    const [loading, setLoading] = useState(false);


    useEffect(() => {
        fetchAttendanceData();
        fetchAttendanceSummary(); // Fetch summary data when component mounts
    }, []);

    const fetchAttendanceData = async () => {
        setLoading(true);
        try {
            const response = await axios.get('http://localhost:5000/api/thongkengaylam');
            setAttendanceData(response.data);
        } catch (error) {
            console.error('Error fetching attendance data', error);
        }
        setLoading(false);
    };

    const fetchAttendanceSummary = async () => {
        setLoading(true);
        try {
            const response = await axios.get('http://localhost:5000/api/thongkengaylam1111');
            setAttendanceData(response.data.entries);
            setSuccessCount(response.data.success_count); // Set successCount from API response
        } catch (error) {
            console.error('Error fetching attendance summary', error);
        }
        setLoading(false);
    };


    const tableStyle = {
        borderCollapse: 'collapse',
        width: '80%',
        margin: 'auto',
    };

    const thStyle = {
        border: '1px solid black',
        padding: '8px',
        backgroundColor: '#8ddc9e',
        textAlign: 'left',
    };

    const tdStyle = {
        border: '1px solid black',
        padding: '8px',
        textAlign: 'left',
    };

    const calculateTotalDaysWorked = () => {
        return attendanceData.reduce((total, record) => {
            return total + (record.KETQUADIEMDANH === 'thành công' ? 1 : 0);
        }, 0);
    };

    return (
        <center>
            <div className="attendance-list">
                <h2>Điểm Danh Nhân Viên</h2>
                {loading ? (
                    <p>Loading...</p>
                ) : (
                    <table style={tableStyle}>
                        <thead>
                            <tr>
                                <th style={thStyle}>ID_NV</th>
                                <th style={thStyle}>Thời Gian</th>
                                <th style={thStyle}>Trạng Thái</th>
                            </tr>
                        </thead>
                        <tbody>
                            {attendanceData.map(record => (
                                <tr key={record.ID_THONGKE}>
                                    <td style={tdStyle}>{record.ID_NV}</td>
                                    <td style={tdStyle}>{new Date(record.THOIGIANDIEMDANH).toLocaleString()}</td>
                                    <td style={tdStyle}>{record.KETQUADIEMDANH}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                )}
            </div>

            <br />

            <div>
                <h2>Thống Kê Ngày Làm Tổng</h2>
                {loading ? (
                    <p>Loading...</p>
                ) : (
                    <div>
                        <table style={tableStyle}>
                            <thead>
                                <tr>
                                    {/* <th style={thStyle}>ID Điểm Danh</th> */}
                                    <th style={thStyle}>ID_NV</th>
                                    {/* <th style={thStyle}>Ngày Làm</th> */}
                                    <th style={thStyle}>Kết Quả Điểm Danh</th>
                                    {/* <th style={thStyle}>Thời Gian Vào Sáng</th>
                                    <th style={thStyle}>Thời Gian Ra Sáng</th>
                                    <th style={thStyle}>Thời Gian Vào Chiều</th>
                                    <th style={thStyle}>Thời Gian Ra Chiều</th> */}
                                </tr>
                            </thead>
                            <tbody>
                                {attendanceData.map(record => (
                                    <tr key={record.ID_TGDD}>
                                        {/* <td style={tdStyle}>{record.ID_TGDD}</td> */}
                                        <td style={tdStyle}>{record.ID_NV}</td>
                                        {/* <td style={tdStyle}>{record.NgayLam ? new Date(record.NgayLam).toLocaleDateString() : '-'}</td> */}
                                        <td style={tdStyle}>{record.KETQUADIEMDANH}</td>
                                        {/* <td style={tdStyle}>{record.THOIGIAN_VAO_SANG}</td>
                                        <td style={tdStyle}>{record.THOIGIAN_RA_SANG}</td>
                                        <td style={tdStyle}>{record.THOIGIAN_VAO_CHIEU}</td>
                                        <td style={tdStyle}>{record.THOIGIAN_RA_CHIEU}</td> */}
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
                {/* <p>Số lần điểm danh thành công: {successCount}</p> */}
            </div>

            <div>
                <h2>Tổng cộng</h2>
                <p>Tổng số ngày làm: {attendanceData.length}</p>
                <p>Số ngày điểm danh thành công: {calculateTotalDaysWorked()}</p>
            </div>
        <br />
            <div>
                <h2>Thống kê theo nhân viên</h2>
                <Link to={"/sta"}>
                <button className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                THỐNG KÊ NV
                </button>
                </Link>
                <h2>Thống kê theo Tháng</h2>
                <Link to={"/mon"}>
                <button className="bg-red-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                THỐNG KÊ THÁNG
                </button>
                </Link>
            </div>
        </center>
    );
};

export default AttendanceList;

