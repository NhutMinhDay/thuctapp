import React, { useState } from 'react';
import axios from 'axios';

const AttendanceList = () => {
    const [employeeId, setEmployeeId] = useState('');
    const [employeeStats, setEmployeeStats] = useState(null);
    const [loading, setLoading] = useState(false);

    // const handleFetchStats = async () => {
    //     if (!employeeId) {
    //         alert('Vui lòng nhập ID_NV để thực hiện thống kê.');
    //         return;
    //     }

    //     setLoading(true);
    // const handleFetchStats = async () => {
    //     setLoading(true);
    //     try {
    //         const response = await axios.get(`http://localhost:5000/api/thongkengaylamcount/${employeeId}`);
    //         setEmployeeStats(response.data);
    //     } catch (error) {
    //         console.error('Error fetching employee stats', error);
    //     }
    //     setLoading(false);
    // };










    const handleFetchStats = async () => {
        setLoading(true);
        try {
            const response = await axios.get(`http://localhost:5000/api/thongkengaylamcount/${employeeId}`);
            setEmployeeStats(response.data);
        } catch (error) {
            console.error('Error fetching employee stats', error);
        }
        setLoading(false);
    };


    
    return (
        <center>
            <div>
                <h2>Thống kê theo nhân viên</h2>
                <input
                    type="text"
                    value={employeeId}
                    onChange={(e) => setEmployeeId(e.target.value)}
                    placeholder="Nhập ID_NV"
                />
                <button
                    onClick={handleFetchStats}
                    className={`bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 focus:outline-none ${loading && 'opacity-50 cursor-not-allowed'}`}
                    disabled={loading}
                >
                    {loading ? "Đang Thống kê..." : "Thống kê"}
                </button>

                {employeeStats && (
                    <div>
                        <h3>Thông tin thống kê cho nhân viên {employeeId}</h3>
                        <p>Tên nhân viên: {employeeStats.TEN_NV}</p>
                        <p>Số ngày làm thành công: {employeeStats.success_days_count}</p>
                        <p>Danh sách điểm danh:</p>
                        <ul>
                            {employeeStats.attendance_records.map(record => (
                                <li key={record.DiemDanhID}>
                                    Ngày làm: {new Date(record.NgayLam).toLocaleDateString()}, Kết quả: {record.KETQUADIEMDANH}
                                </li>
                            ))}
                        </ul>
                    </div>
                )}
            </div>
        </center>
    );
};

export default AttendanceList;
