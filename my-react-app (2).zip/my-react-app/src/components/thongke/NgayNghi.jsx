import React, { useState, useEffect } from 'react';
import axios from 'axios';

const NgayNghi = () => {
  const [attendanceData, setAttendanceData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [monthOptions, setMonthOptions] = useState([]);
  const [yearOptions, setYearOptions] = useState([]);
  const [selectedMonth, setSelectedMonth] = useState('');
  const [selectedYear, setSelectedYear] = useState('');

  useEffect(() => {
    const fetchAttendanceData = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/thongke/ngaynghi');
        const data = response.data;
        setAttendanceData(data);
        initializeMonthYearOptions(data); // Khởi tạo danh sách tháng và năm có sẵn
        setFilteredData(data); // Khởi tạo dữ liệu hiển thị ban đầu
      } catch (error) {
        console.error('Error fetching attendance data:', error);
      }
    };

    fetchAttendanceData();
  }, []);

  // Hàm khởi tạo danh sách tháng và năm
  const initializeMonthYearOptions = (data) => {
    const monthSet = new Set();
    const yearSet = new Set();
    data.forEach((item) => {
      monthSet.add(item.Thang);
      yearSet.add(item.Nam);
    });

    const sortedMonths = Array.from(monthSet).sort((a, b) => a - b);
    const sortedYears = Array.from(yearSet).sort((a, b) => a - b);

    setMonthOptions(['Tất cả', ...sortedMonths]); // Thêm tùy chọn 'Tất cả'
    setYearOptions(['Tất cả', ...sortedYears]); // Thêm tùy chọn 'Tất cả'
    setSelectedMonth('Tất cả'); // Chọn 'Tất cả' làm giá trị mặc định
    setSelectedYear('Tất cả'); // Chọn 'Tất cả' làm giá trị mặc định
  };

  // Hàm xử lý khi thay đổi năm
  const handleYearChange = (event) => {
    setSelectedYear(event.target.value);
  };

  // Hàm xử lý khi thay đổi tháng
  const handleMonthChange = (event) => {
    setSelectedMonth(event.target.value);
  };

  // Hàm xử lý khi thay đổi input tìm kiếm
  const handleSearchChange = (event) => {
    const searchTerm = event.target.value.toLowerCase();
    let filtered = attendanceData.filter(
      (data) =>
        data.ID_NV.toLowerCase().includes(searchTerm) ||
        data.TEN_NV.toLowerCase().includes(searchTerm) ||
        data.EMAIL_NV.toLowerCase().includes(searchTerm) ||
        data.SDT_NV.toLowerCase().includes(searchTerm) ||
        data.Thang.toString().includes(searchTerm) ||
        data.Nam.toString().includes(searchTerm)
    );

    // Lọc theo tháng và năm nếu đã chọn
    if (selectedMonth !== 'Tất cả') {
      filtered = filtered.filter((data) => data.Thang.toString() === selectedMonth);
    }
    if (selectedYear !== 'Tất cả') {
      filtered = filtered.filter((data) => data.Nam.toString() === selectedYear);
    }

    setFilteredData(filtered);
  };

  // Hàm reset tất cả lựa chọn
  const resetFilters = () => {
    setSelectedMonth('Tất cả');
    setSelectedYear('Tất cả');
    setFilteredData(attendanceData);
  };

  return (
    <div className="p-4 w-11/12 ml-auto">
      <h1 className="text-2xl font-bold mb-4 text-center uppercase">Thống Kê Số Ngày Nghỉ</h1>

      {/* Thêm thanh chọn tháng và năm */}
      <div className="flex justify-end items-center mb-4 mx-auto w-3/4">
        <label htmlFor="month" className="mr-2">
          Tháng:
        </label>
        <select
          id="month"
          value={selectedMonth}
          onChange={handleMonthChange}
          className="px-3 py-2 border border-gray-300 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 rounded-md text-sm text-gray-900"
        >
          {monthOptions.map((month, index) => (
            <option key={index} value={month}>
              {month}
            </option>
          ))}
        </select>

        <label htmlFor="year" className="ml-4 mr-2">
          Năm:
        </label>
        <select
          id="year"
          value={selectedYear}
          onChange={handleYearChange}
          className="px-3 py-2 border border-gray-300 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 rounded-md text-sm text-gray-900"
        >
          {yearOptions.map((year, index) => (
            <option key={index} value={year}>
              {year}
            </option>
          ))}
        </select>

        {/* Button reset */}
        <button
          onClick={resetFilters}
          className="ml-4 px-4 py-2 bg-blue-500 text-white rounded-md focus:outline-none hover:bg-blue-600"
        >
          Đặt lại
        </button>
      </div>

      {/* Thêm input tìm kiếm */}
      <div className="mb-4 mx-auto w-3/4 flex justify-end">
        <input
          type="text"
          placeholder="Tìm kiếm theo Mã nhân viên, Tên nhân viên, Email, SĐT"
          className="px-3 py-2 border border-gray-300 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 rounded-md text-sm text-gray-900 w-1/2"
          onChange={handleSearchChange}
        />
      </div>
      <div className="overflow-x-auto">
        <table className="min-w-full bg-white divide-y divide-gray-200">
          <thead className="bg-gray-100 text-gray-800 ">
            <tr> 
              <th className="px-6 py-3 text-center text-xs font-semibold uppercase tracking-wider">STT</th>
              <th className="px-6 py-3 text-center text-xs font-semibold uppercase tracking-wider">Mã Nhân viên</th>
              <th className="px-6 py-3 text-center text-xs font-semibold uppercase tracking-wider">Họ Tên</th>
              <th className="px-6 py-3 text-center text-xs font-semibold uppercase tracking-wider">Email</th>
              <th className="px-6 py-3 text-center text-xs font-semibold uppercase tracking-wider">Số điện thoại</th>
              <th className="px-6 py-3 text-center text-xs font-semibold uppercase tracking-wider">Tháng</th>
              <th className="px-6 py-3 text-center text-xs font-semibold uppercase tracking-wider">Năm</th>
              <th className="px-6 py-3 text-center text-xs font-semibold uppercase tracking-wider">Số Ngày Làm</th>
              <th className="px-6 py-3 text-center text-xs font-semibold uppercase tracking-wider">Số Ngày Nghỉ</th>
              <th className="px-6 py-3 text-center text-xs font-semibold uppercase tracking-wider">Tổng Ngày</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {filteredData.map((data, index) => (
              <tr key={index} className="transition-all hover:bg-gray-100">
                <td className="px-6 py-4 text-center whitespace-nowrap text-sm font-medium text-gray-900">{index + 1}</td>
                <td className="px-6 py-4 text-center whitespace-nowrap text-sm font-medium text-gray-900">{data.ID_NV}</td>
                <td className="px-6 py-4 text-center whitespace-nowrap text-sm text-gray-700">{data.TEN_NV}</td>
                <td className="px-6 py-4 text-center whitespace-nowrap text-sm text-gray-700">{data.EMAIL_NV}</td>
                <td className="px-6 py-4 text-center whitespace-nowrap text-sm text-gray-700">{data.SDT_NV}</td>
                <td className="px-6 py-4 text-center whitespace-nowrap text-sm text-gray-700">{data.Thang}</td>
                <td className="px-6 py-4 text-center whitespace-nowrap text-sm text-gray-700">{data.Nam}</td>
                <td className="px-6 py-4 text-center whitespace-nowrap text-sm text-gray-700">{data.SoNgayLam}</td>
                <td className="px-6 py-4 text-center whitespace-nowrap text-sm text-gray-700">{data.SoNgayNghi}</td>
                <td className="px-6 py-4 text-center whitespace-nowrap text-sm text-gray-700">{data.TongNgay}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default NgayNghi;
