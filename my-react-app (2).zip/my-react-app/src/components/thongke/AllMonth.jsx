import React, { useState, useEffect } from 'react';
import axios from 'axios';

const AllMonth = () => {
  const [attendanceData, setAttendanceData] = useState([]);

  useEffect(() => {
    const fetchAttendanceData = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/thongke/ngaylam');
        setAttendanceData(response.data);
      } catch (error) {
        console.error('Error fetching attendance data:', error);
      }
    };

    fetchAttendanceData();
  }, []);
  return (
    <div className="p-4 w-5/6 m-auto ">
      <h1 className="text-3xl font-bold mb-6 text-gray-800 uppercase text-center">Thống Kê Tất Cả Tháng Làm</h1>
      <div className="overflow-x-auto">
        <table className="min-w-full bg-white divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
            <th className="px-6 py-3 text-center text-xs font-medium text-gray-800 uppercase tracking-wider">STT</th>
              <th className="px-6 py-3 text-center text-xs font-medium text-gray-800 uppercase tracking-wider">Mã Nhân viên</th>
              <th className="px-6 py-3 text-center text-xs font-medium text-gray-800 uppercase tracking-wider">Họ Tên</th>
              <th className="px-6 py-3 text-center text-xs font-medium text-gray-800 uppercase tracking-wider">Số điện thoại</th>
              <th className="px-6 py-3 text-center text-xs font-medium text-gray-800 uppercase tracking-wider">Email</th>
              <th className="px-6 py-3 text-center text-xs font-medium text-gray-800 uppercase tracking-wider">Tháng</th>
              <th className="px-6 py-3 text-center text-xs font-medium text-gray-800 uppercase tracking-wider">Năm</th>
              <th className="px-6 py-3 text-center text-xs font-medium text-gray-800 uppercase tracking-wider">Số Ngày Làm</th>
              <th className="px-6 py-3 text-center text-xs font-medium text-gray-800 uppercase tracking-wider">Tổng Ngày</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200 text-center">
            {attendanceData.map((data, index) => (
              <tr key={`${data.ID_NV}-${index}`}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{index+1}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{data.ID_NV}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{data.TEN_NV}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{data.SDT_NV}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{data.EMAIL_NV}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{data.Thang}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{data.Nam}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{data.SoNgayLam}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{data.TongNgay}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AllMonth;
