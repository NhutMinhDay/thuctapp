import React, { useState, useEffect, useCallback } from "react";
import axios from "axios";

const MonthlyAttendance = () => {
  const currentYear = new Date().getFullYear();
  const [month, setMonth] = useState(new Date().getMonth() + 1); // Current month
  const [year, setYear] = useState(currentYear); // Current year
  const [attendanceData, setAttendanceData] = useState([]);

  const fetchAttendanceData = useCallback(async () => {
    try {
      const response = await axios.get(
        `http://localhost:5000/api/monthly-attendance/${month}/${year}`
      );
      setAttendanceData(response.data);
    } catch (error) {
      console.error("Error fetching attendance data:", error);
    }
  }, [month, year]);

  useEffect(() => {
    fetchAttendanceData();
  }, [fetchAttendanceData]);

  const handleMonthChange = (e) => {
    setMonth(e.target.value);
  };

  const handleYearChange = (e) => {
    setYear(parseInt(e.target.value, 10)); // Ensure the year is an integer
  };

  return (
    <div className="p-4 w-5/6 m-auto">
      <h1 className="text-3xl font-bold mb-6 text-gray-800 uppercase text-center">
        Thống Kê Theo Từng Tháng
      </h1>
      <form className="flex flex-wrap mb-6 gap-3 bg-gray-100 p-4 rounded-lg shadow-lg">
        <div className="w-full sm:w-1/2 md:w-1/4 mb-4 sm:mb-0">
          <label className="block text-lg font-medium text-gray-700 mb-2">
            Tháng:
          </label>
          <select
            value={month}
            onChange={handleMonthChange}
            className="block w-full p-2 border border-gray-500 rounded-md bg-gray-200 text-gray-800 font-semibold"
          >
            {[...Array(12).keys()].map((m) => (
              <option key={m + 1} value={m + 1}>
                {m + 1}
              </option>
            ))}
          </select>
        </div>
        <div className="w-full sm:w-1/2 md:w-1/4">
          <label className="block text-lg font-medium text-gray-700 mb-2">
            Năm:
          </label>
          <select
            value={year}
            onChange={handleYearChange}
            className="block w-full p-2 border border-gray-500 rounded-md bg-gray-200 text-gray-800 font-semibold"
          >
            {[...Array(10).keys()].map((y) => (
              <option key={currentYear - y} value={currentYear - y}>
                {currentYear - y}
              </option>
            ))}
          </select>
        </div>
      </form>
      <div className="overflow-x-auto">
        <table className="min-w-full bg-white divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-800 uppercase tracking-wider">
                STT
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-800 uppercase tracking-wider">
                Mã Nhân viên
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-800 uppercase tracking-wider">
                Họ Tên
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-800 uppercase tracking-wider">
                Số điện thoại
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-800 uppercase tracking-wider">
                Email
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-800 uppercase tracking-wider">
                Tháng
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-800 uppercase tracking-wider">
                Năm
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-800 uppercase tracking-wider">
                Số Ngày Làm
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-800 uppercase tracking-wider">
                Tổng Ngày
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {attendanceData.map((data, index) => (
              <tr key={`${data.ID_NV}-${index}`}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  {index + 1}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  {data.ID_NV}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                  {data.TEN_NV}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                  {data.SDT_NV}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                  {data.EMAIL_NV}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                  {data.Thang}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                  {data.Nam}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                  {data.SoNgayLam}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                  {data.TongNgay}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default MonthlyAttendance;
