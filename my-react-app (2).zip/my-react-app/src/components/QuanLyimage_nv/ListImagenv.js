import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import FormImage from "./FormImage";

const ListImagenv = () => {
  const [imageList, setImageList] = useState([]);
  const [selectedImage, setSelectedImage] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchImageList = async () => {
      try {
        const response = await axios.get("/api/image_base64_nv");
        setImageList(response.data);
      } catch (err) {
        setError("Đã xảy ra lỗi khi lấy dữ liệu từ server.");
      } finally {
        setLoading(false);
      }
    };

    fetchImageList();
  }, []);

  const handleDelete = async (id) => {
    try {
      await axios.delete(`api/image_base64_nv/${id}`);
      setImageList(imageList.filter((image) => image.ID_IMAGE !== id));
      console.log("Image deleted successfully!");
    } catch (error) {
      console.error("Error deleting image:", error);
    }
  };

  const handleUpdate = (id) => {
    const imageToUpdate = imageList.find((image) => image.ID_IMAGE === id);
    setSelectedImage(imageToUpdate);
  };

  if (error) return <div>{error}</div>;

  return (
    <div className="flex flex-col">
      <div className="flex justify-between w-full mb-4">
        <h2 className="ml-36 text-2xl font-bold">
          Danh Sách Ảnh Của Nhân viên
        </h2>
        <Link to={"/addimage"}>
          <button className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
            THÊM ẢNH
          </button>
        </Link>
      </div>
      <table className="mt-5 ml-32 mr-2 border-collapse border border-gray-500 text-sm">
        <thead>
          <tr className="text-base uppercase">
            <th className="border border-gray-700 p-3">Mã Nhân Viên</th>
            <th className="border border-gray-700 p-3">Ảnh Trái</th>
            <th className="border border-gray-700 p-3">Ảnh Phải</th>
            <th className="border border-gray-700 p-3">Ảnh Trên</th>
            <th className="border border-gray-700 p-3">Ảnh Dưới</th>
            <th className="border border-gray-700 p-3">Ảnh Giữa</th>
            <th className="border border-gray-700 p-3">HÀNH ĐỘNG</th>
          </tr>
        </thead>
        <tbody>
          {imageList.map((image) => (
            <tr key={image.ID_IMAGE} className="border border-gray-700">
              <td className="border border-gray-700 text-center">
                <p className="font-mono text-base">{image.ID_NV}</p>
              </td>
              <td className="border border-gray-700 p-2">
                <img
                  src={image.IMAGE_LEFT}
                  style={{ width: "200px", height: "200px" }}
                  alt={`Ảnh ${image.ID_IMAGE}`}
                />
              </td>
              <td className="border border-gray-700 p-2">
                <img
                  src={image.IMAGE_RIGHT}
                  style={{ width: "200px", height: "200px" }}
                  alt={`Ảnh ${image.ID_IMAGE}`}
                />
              </td>
              <td className="border border-gray-700 p-2">
                <img
                  src={image.IMAGE_TOP}
                  style={{ width: "200px", height: "200px" }}
                  alt={`Ảnh ${image.ID_IMAGE}`}
                />
              </td>
              <td className="border border-gray-700 p-2">
                <img
                  src={image.IMAGE_BOTTOM}
                  style={{ width: "200px", height: "200px" }}
                  alt={`Ảnh ${image.ID_IMAGE}`}
                />
              </td>
              <td className="border border-gray-700 p-2">
                <img
                  src={image.IMAGE_BETWEEN}
                  style={{ width: "200px", height: "200px" }}
                  alt={`Ảnh ${image.ID_IMAGE}`}
                />
              </td>
              <td className="border flex flex-col py-11 px-4 gap-4">
                <button
                  className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
                  onClick={() => handleUpdate(image.ID_IMAGE)}
                >
                  Cập Nhật
                </button>
                <button
                  className="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded"
                  onClick={() => handleDelete(image.ID_IMAGE)}
                >
                  Xóa
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="ml-20">
        {selectedImage && <FormImage entry={selectedImage} />}
      </div>
    </div>
  );
};

export default ListImagenv;
