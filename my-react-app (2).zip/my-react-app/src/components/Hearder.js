import React, { useState, useEffect, useRef, useContext } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Context } from "./Admin/Context";

const Header = ({ isLoggedIn }) => {
  const { logout } = useContext(Context);
  const navigate = useNavigate();

  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const closeMenu = (e) => {
    if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
      setIsOpen(false);
    }
  };

  const handleLogout = async () => {
    await logout();
    // navigate("/log");
    window.location.href = '/log';
  };

  useEffect(() => {
    document.addEventListener("click", closeMenu);
    return () => document.removeEventListener("click", closeMenu);
  }, []);

  // if (!isLoggedIn) {
  //   return null;
  // }

  return (
    <header className="fixed left-0 top-0 h-full flex flex-col sm:w-[20%] md:w-[15%] lg:w-[10%]">
      <div className="mx-auto p-3 relative">
        <div className="flex items-center justify-between">
          <Link
            to={"/"}
            className="text-gray-700 hover:underline font-bold text-sm sm:text-xl flex flex-wrap"
          >
            <span>Face</span>
            <span className="text-gray-900">NMH</span>
          </Link>
          <button
            className="block sm:hidden text-gray-800 focus:outline-none"
            onClick={toggleMenu}
          >
            <svg
              className="w-6 h-6"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M4 6h16M4 12h16m-7 6h7"
              />
            </svg>
          </button>
        </div>

        {isLoggedIn && (
          <div>
            <ul
              className={`font-semibold flex flex-col mt-4 sm:flex ${
                isOpen ? "block" : "hidden"
              }`}
              ref={dropdownRef}
            >
              <li>
                <Link
                  to={"/list"}
                  className="text-gray-700 hover:underline block py-2"
                >
                  Điểm Danh
                </Link>
              </li>
              <li>
                <Link
                  to={"/listqr"}
                  className="text-gray-700 hover:underline block py-2"
                >
                  Mã QR
                </Link>
              </li>
              <li>
                <Link
                  to={"/listimage"}
                  className="text-gray-700 hover:underline block py-2"
                >
                  Ảnh Nhân Viên
                </Link>
              </li>
              <li>
                <Link
                  to={"/edit"}
                  className="text-gray-700 hover:underline block py-2"
                >
                  Cập Nhật
                </Link>
              </li>



              <Link to={"/edit"} className="text-slate-700 hover:underline">
              <li>Cập Nhật</li>
              </Link>


              <Link to={"/delete"} className="text-slate-700 hover:underline">
                <li>Xóa</li>
              </Link>


              <Link to={"/seach"} className="text-slate-700 hover:underline">
                <li>Tìm Tài Khoản</li>
              </Link>

              
              <Link to={"/edil"} className="text-slate-700 hover:underline">
                <li>Liệt kê nhân viên</li>
              </Link>



              <li>
                <Link
                  to={"/delete"}
                  className="text-gray-700 hover:underline block py-2"
                >
                  Xóa
                </Link>
              </li>
              <li>
                <Link
                  to={"/seach"}
                  className="text-gray-700 hover:underline block py-2"
                >
                  Tìm Tài Khoản
                </Link>
              </li>
              <li>
                <button
                  onClick={handleLogout}
                  className="text-gray-800 hover:text-gray-900 py-2 transition duration-300 ease-in-out transform hover:scale-105"
                >
                  Đăng Xuất
                </button>
              </li>

              {/* Dropdown for Statistics */}
              <li className="relative">
                <span
                  className="text-gray-700 cursor-pointer hover:underline flex items-center py-2"
                  onClick={toggleMenu}
                >
                  Thống Kê
                  <span className="ml-1">&#9662;</span>
                </span>
                <ul
                  className={`absolute left-0 mt-2 bg-white shadow-lg rounded-md py-1 ${
                    isOpen ? "block" : "hidden"
                  }`}
                >
                  <li>
                    <Link
                      to={"/thongkethangnam"}
                      className="block px-4 py-2 text-gray-700 hover:bg-gray-100"
                    >
                      Thống kê tháng/năm
                    </Link>
                  </li>
                  <li>
                    <Link
                      to={"/thongketatca"}
                      className="block px-4 py-2 text-gray-700 hover:bg-gray-100"
                    >
                      Thống kê tất cả
                    </Link>
                  </li>
                  <li>
                    <Link
                      to={"/thongkengaynghi"}
                      className="block px-4 py-2 text-gray-700 hover:bg-gray-100"
                    >
                      Thống kê ngày nghỉ
                    </Link>

                

                  </li>
                  
                </ul>
              </li>
              
            </ul>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
