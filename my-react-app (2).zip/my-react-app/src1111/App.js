
import React, { useContext } from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Header from './components/Hearder';
import CreateThoiGianDiemDanh from "./components/quanlythoigian/CreateThoiGianDiemDanh";
import ThoiGianDiemDanhList from "./components/quanlythoigian/ThoiGianDiemDanhList";
import UpdateForm from "./components/quanlythoigian/UpdateForm";
import AddQr from "./components/quanlyQR/AddQr";
import ListQr from "./components/quanlyQR/ListQr";
import FormQr from "./components/quanlyQR/FormQr";
import AddImagenv from "./components/QuanLyimage_nv/AddImagenv";
import ListImagenv from "./components/QuanLyimage_nv/ListImagenv";
import FormImage from "./components/QuanLyimage_nv/FormImage";
import AddTK from "./components/Quanlytaikhoan/AddTK";
import XoaTK from "./components/Quanlytaikhoan/XoaTK";
import TimKiem from "./components/Quanlytaikhoan/TimKiem";
import LoginAdmin from "./components/Admin/LoginAdmin";
import Profile from "./components/Admin/Profile";
import Them from './components/Quanlytaikhoan/Them';
import ALL from './components/Quanlytaikhoan/ALL';
import { Context } from "./components/Admin/Context";


function App() {
  const { state } = useContext(Context);
  const { isLoggedIn } = state;
  console.log(isLoggedIn);
  return (
    <BrowserRouter>
      <div className="flex flex-col sm:flex-row">
        <Header />
        <main className="flex-1 m-4 p-2">
          <Routes>
            <Route path="/create" element={<CreateThoiGianDiemDanh />} />
            <Route path="/list" element={<ThoiGianDiemDanhList />} />
            <Route path="/update/:id" element={<UpdateForm />} />
            <Route path="/addqr" element={<AddQr />} />
            <Route path="/listqr" element={<ListQr />} />
            <Route path="/updateqr/:id" element={<FormQr />} />
            <Route path="/addimage" element={<AddImagenv />} />
            <Route path="/listimage" element={<ListImagenv />} />
            <Route path="/updateimage/:id" element={<FormImage />} />
            <Route path="/edit" element={<AddTK />} />
            <Route path="/seach" element={<TimKiem />} />
            <Route path="/delete" element={<XoaTK />} />
            <Route path="/log" element={<LoginAdmin />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/ad" element={<Them />} />
            <Route path="/all" element={<ALL />} />
            {/* <Route path="/pro4" element={<Navigate to="/log" />} /> */}
            <Route
          path="/pro4" element={isLoggedIn ? <Profile /> : <Navigate to="/log" />}/>
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  );
}
export default App;
