
// Profile.js
import { useContext } from 'react';
import { Context } from "./Context";

const Profile = () => {
  const { state } = useContext(Context);
  const { isLoggedIn, userInfo } = state;

  

  if (!isLoggedIn) {
    return <p><center>Bạn chưa đăng nhập</center></p>;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-500 to-pink-600 flex items-baseline justify-center text-slate-800 font-semibold">
      <div className="mt-24 p-8 bg-white rounded-lg shadow-lg">
        <h2 className="text-2xl mb-4">Welcome, {userInfo.TEN_ADMIN}</h2>
        <p className="text-lg">Tên Admin: {userInfo.TEN_ADMIN}</p>
        <p className="text-lg">ID_admin: {userInfo.ID_ADMIN}</p>
        <p className="text-lg">User: {userInfo.USER}</p>
        <p className="text-lg">Mật Khẩu: {userInfo.MK}</p>

      </div>
    </div>
  );
};

export default Profile;
