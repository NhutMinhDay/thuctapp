// import React, { createContext, useEffect, useReducer } from "react";
// import md5 from "md5";
// import axios from "axios";

// const initialState = {
//   username: "",
//   password: "",
//   loading: false,
//   error: null,
//   isLoggedIn: false,
//   userInfo: null,
// };

// const AuthContext = createContext();

// function authReducer(state, action) {
//   switch (action.type) {
//     case "FIELD":
//       return {
//         ...state,
//         [action.fieldName]: action.payload,
//       };
//     case "LOGIN_START":
//       return {
//         ...state,
//         loading: true,
//         error: null,
//       };
//     case "LOGIN_SUCCESS":
//       return {
//         ...state,
//         loading: false,
//         isLoggedIn: true,
//         userInfo: action.payload.employee,
//       };
//     case "LOGIN_FAILURE":
//       return {
//         ...state,
//         loading: false,
//         error: action.payload,
//       };
//     case "LOGOUT":
//       return {
//         ...state,
//         isLoggedIn: false,
//         userInfo: null,
//       };
//     default:
//       return state;
//   }
// }

// const AuthProvider = ({ children }) => {
//   const [state, dispatch] = useReducer(authReducer, initialState);
//   useEffect(() => {
//     console.log("Auth State:", state);
//   }, [state]);

//   const login = async (username, password) => {
//     dispatch({ type: "LOGIN_START" });
//     try {
//       const hashedPassword = md5(password);
//       const response = await axios.post("http://localhost:5000/api/login", {
//         username,
//         password: hashedPassword,
//       });
//       dispatch({ type: "LOGIN_SUCCESS", payload: response.data });
//     } catch (error) {
//       dispatch({
//         type: "LOGIN_FAILURE",
//         payload: error.response
//           ? error.response.data.error
//           : "Something went wrong",
//       });
//     }
//   };
//   const logout = () => {
//     dispatch({ type: "LOGOUT" });
//   };
//   const value = { state, dispatch, login,logout };
//   return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
// };

// export { AuthProvider, AuthContext };



import React, { createContext, useEffect, useReducer } from "react";
import md5 from "md5";
import axios from "axios";

const initialState = {
  user: "",
  MK: "",
  loading: false,
  error: null,
  isLoggedIn: false,
  userInfo: null,
};


const AuthContext = createContext();


function authReducer(state, action) {
  switch (action.type) {
    case "FIELD":
      return {
        ...state,
        [action.fieldName]: action.payload,
      };
    case "LOGIN_START":
      return {
        ...state,
        loading: true,
        error: null,
      };
    case "LOGIN_SUCCESS":
      return {
        ...state,
        loading: false,
        isLoggedIn: true,
        userInfo: action.payload.employee,
      };
    case "LOGIN_FAILURE":
      return {
        ...state,
        loading: false,
        error: action.payload,
      };
    case "LOGOUT":
      return {
        ...state,
        isLoggedIn: false,
        userInfo: null,
      };
    default:
      return state;
  }
}



const AuthProvider = ({ children }) => {
  const [state, dispatch] = useReducer(authReducer, initialState);

  useEffect(() => {
    console.log("Auth State:", state);
  }, [state]);

  const login = async (username, password) => {
    dispatch({ type: "LOGIN_START" });
    try {
      const hashedPassword = md5(password);
      const response = await axios.post("http://localhost:5000/api/login", {
        user: username,
        MK: hashedPassword,
      });
      dispatch({ type: "LOGIN_SUCCESS", payload: response.data });
    } catch (error) {
      dispatch({
        type: "LOGIN_FAILURE",
        payload: error.response
          ? error.response.data.error
          : "Something went wrong",
      });
    }
  };

  const logout = () => {
    dispatch({ type: "LOGOUT" });
  };

  const value = { state, dispatch, login, logout };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export { AuthProvider, AuthContext };
