import React, { useContext } from "react";
import { AuthContext } from "../components/users/AuthContext";
import { Navigate } from "react-router-dom";

const Login = () => {
  const { state, dispatch, login } = useContext(AuthContext);

  const { username, password, loading, error, isLoggedIn } = state;
  const handleSubmit = (e) => {
    e.preventDefault();
    login(username, password);
    alert("LOGIN SUCCESSFULL!!!");
  };

  const handleChange = (e) => {
    dispatch({
      type: "FIELD",
      fieldName: e.target.name,
      payload: e.target.value,
    });
  };
  if (isLoggedIn) {
    return <Navigate to="/profile" />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center font-semibold">
      <form
        onSubmit={handleSubmit}
        className="bg-slate-200 rounded-lg shadow-lg p-8 w-96"
      >
        <div className="mb-5">
          <label htmlFor="username" className="block text-lg text-gray-800">
            Username:
          </label>
          <input
            type="text"
            name="username"
            id="username"
            value={username}
            onChange={handleChange}
            className="my-3 p-3 w-full rounded-md border-gray-800 shadow-lg focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
          />
        </div>
        <div className="mb-5">
          <label htmlFor="password" className="block text-lg text-gray-800">
            Password:
          </label>
          <input
            type="password"
            name="password"
            id="password"
            value={password}
            onChange={handleChange}
            className="my-3 p-3 w-full rounded-md border-gray-800 shadow-lg focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
          />
        </div>
        {error && <p className="text-red-500">{error}</p>}
        <button
          type="submit"
          disabled={loading}
          className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-md px-4 py-2 mt-4 disabled:bg-gray-400 disabled:cursor-not-allowed"
        >
          {loading ? "Logging in..." : "Login"}
        </button>
      </form>
    </div>
  );
};

export default Login;

// import React, { useReducer } from 'react';
// import axios from 'axios';
// import { useNavigate } from 'react-router-dom';
// import md5 from 'md5'; // Thêm thư viện mã hóa MD5

// const initialState = {
//   username: '',
//   password: '',
//   loading: false,
//   error: null,
//   isLoggedIn: false,
//   userInfo: null,
// };

// function reducer(state, action) {
//   switch (action.type) {
//     case 'FIELD':
//       return {
//         ...state,
//         [action.fieldName]: action.payload,
//       };
//     case 'LOGIN_START':
//       return {
//         ...state,
//         loading: true,
//         error: null,
//       };
//     case 'LOGIN_SUCCESS':
//       return {
//         ...state,
//         loading: false,
//         isLoggedIn: true,
//         userInfo: action.payload.employee,
//       };
//     case 'LOGIN_FAILURE':
//       return {
//         ...state,
//         loading: false,
//         error: action.payload,
//       };
//     default:
//       return state;
//   }
// }

// const Login = () => {
//   const [state, dispatch] = useReducer(reducer, initialState);
//   const navigate = useNavigate();

//   const { username, password, loading, error, isLoggedIn, userInfo } = state;
//   console.log(state);
//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     dispatch({ type: 'LOGIN_START' });

//     try {
//       const hashedPassword = md5(password); // Mã hóa mật khẩu với MD5
//       const response = await axios.post('http://localhost:5000/api/login', {
//         username,
//         password: hashedPassword, // Gửi mật khẩu đã được mã hóa
//       });
//       dispatch({ type: 'LOGIN_SUCCESS', payload: response.data });
//       console.log("Đăng nhập thành công: ", username)
//       //   navigate('/dashboard');
//     } catch (error) {
//       dispatch({
//         type: 'LOGIN_FAILURE',
//         payload: error.response ? error.response.data.error : 'Something went wrong',
//       });
//     }
//   };

//   const handleChange = (e) => {
//     dispatch({
//       type: 'FIELD',
//       fieldName: e.target.name,
//       payload: e.target.value,
//     });
//   };

//   if (isLoggedIn) {
//     return (
//       <div className="min-h-screen bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center text-slate-800 font-semibold">
//         <div className="p-8 bg-white rounded-lg shadow-lg">
//           <h2 className="text-2xl mb-4">Welcome, {userInfo.TEN_NV}</h2>
//           <p className="text-lg">ID Nhân viên: {userInfo.ID_NV}</p>
//           {/* Hiển thị thêm thông tin nhân viên khác ở đây */}
//         </div>
//       </div>
//     );
//   }

//   return (
//     <div className="min-h-screen bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center font-semibold">
//       <form onSubmit={handleSubmit} className="bg-slate-200 rounded-lg shadow-lg p-8 w-96">
//         <div className="mb-5">
//           <label htmlFor="username" className="block text-lg text-gray-800">Username:</label>
//           <input
//             type="text"
//             name="username"
//             id="username"
//             value={username}
//             onChange={handleChange}
//             className="my-3 p-3 w-full rounded-md border-gray-800 shadow-lg focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
//           />
//         </div>
//         <div className="mb-5">
//           <label htmlFor="password" className="block text-lg text-gray-800">Password:</label>
//           <input
//             type="password"
//             name="password"
//             id="password"
//             value={password}
//             onChange={handleChange}
//             className="my-3 p-3 w-full rounded-md border-gray-800 shadow-lg focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
//           />
//         </div>
//         {error && <p className="text-red-500">{error}</p>}
//         <button type="submit" disabled={loading} className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-md px-4 py-2 mt-4 disabled:bg-gray-400 disabled:cursor-not-allowed">
//           {loading ? 'Logging in...' : 'Login'}
//         </button>
//       </form>
//     </div>
//   );
// };

// export default Login;
