import React, { useContext } from "react";
import { AuthContext } from "../components/users/AuthContext";
import { Navigate } from "react-router-dom";

const Login = () => {
  const { state, dispatch, login } = useContext(AuthContext);

  const { username, password, loading, error, isLoggedIn } = state;
  const handleSubmit = (e) => {
    e.preventDefault();
    login(username, password);
  };

  const handleChange = (e) => {
    dispatch({
      type: "FIELD",
      fieldName: e.target.name,
      payload: e.target.value,
    });
  };
  if (isLoggedIn) {
    return <Navigate to="/profile" />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br  via-blue-500  to-teal-500 from-pink-600 flex items-center justify-center font-semibold">
      <form
        onSubmit={handleSubmit}
        className="bg-slate-200 rounded-lg shadow-lg p-8 w-96"
      >
        <div className="mb-5">
          <label htmlFor="username" className="block text-lg text-gray-800">
            Tên tài khoản:
          </label>
          <input
            type="text"
            name="username"
            id="username"
            value={username}
            onChange={handleChange}
            className="my-3 p-3 w-full rounded-md border-gray-800 shadow-lg focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
          />
        </div>
        <div className="mb-5">
          <label htmlFor="password" className="block text-lg text-gray-800">
            Mật khẩu:
          </label>
          <input
            type="password"
            name="password"
            id="password"
            value={password}
            onChange={handleChange}
            className="my-3 p-3 w-full rounded-md border-gray-800 shadow-lg focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
          />
        </div>
        {error && <p className="text-red-500">{error}</p>}
        <button
          type="submit"
          disabled={loading}
          className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-md px-4 py-2 mt-4 disabled:bg-gray-400 disabled:cursor-not-allowed"
        >
          {loading ? "Logging in..." : "Login"}
        </button>
      </form>
    </div>
  );
};

export default Login;