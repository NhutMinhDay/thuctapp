// import React, { useEffect, useRef, useState } from "react";
// import * as faceapi from "face-api.js";
// import axios from "axios";
// import QRCodeScanner from "../components/QRCodeScanner";
// import CheckSuccess from "../components/CheckSuccess";

// const CaptureImage = () => {
//   const videoRef = useRef();
//   const canvasRef = useRef();
//   const imageRef = useRef();
//   const streamRef = useRef(null);
//   const intervalIdRef = useRef(null);
//   const [isChecking, setIsChecking] = useState(false);

//   useEffect(() => {
//     const loadModels = async () => {
//       await Promise.all([
//         faceapi.nets.tinyFaceDetector.loadFromUri("/models"),
//         faceapi.nets.faceLandmark68Net.loadFromUri("/models"),
//         faceapi.nets.faceRecognitionNet.loadFromUri("/models"),
//         faceapi.nets.faceExpressionNet.loadFromUri("/models"),
//       ]);
//       startVideo();
//     };

//     const startVideo = () => {
//       navigator.mediaDevices
//         .getUserMedia({ video: true })
//         .then((currentStream) => {
//           streamRef.current = currentStream;
//           videoRef.current.srcObject = currentStream;
//         })
//         .catch((err) => {
//           console.log(err);
//         });
//     };

//     const stopVideo = () => {
//       if (streamRef.current) {
//         streamRef.current.getTracks().forEach((track) => track.stop());
//       }
//     };

//     const faceMyDetect = () => {
//       const intervalId = setInterval(async () => {
//         const videoElement = videoRef.current;
//         if (!videoElement || videoElement.readyState !== 4 || isChecking) {
//           return;
//         }

//         const detections = await faceapi
//           .detectAllFaces(videoElement, new faceapi.TinyFaceDetectorOptions())
//           .withFaceLandmarks()
//           .withFaceExpressions();

//         const canvas = faceapi.createCanvasFromMedia(videoElement);
//         faceapi.matchDimensions(canvas, {
//           width: 940,
//           height: 650,
//         });

//         const resized = faceapi.resizeResults(detections, {
//           width: 940,
//           height: 650,
//         });

//         const context = canvasRef.current.getContext("2d");
//         context.clearRect(0, 0, canvas.width, canvas.height);

//         faceapi.draw.drawDetections(canvas, resized);
//         faceapi.draw.drawFaceExpressions(canvas, resized);

//         context.drawImage(canvas, 0, 0);

//         if (resized.length > 0) {
//           const probability = await faceapi
//             .detectSingleFace(
//               videoElement,
//               new faceapi.TinyFaceDetectorOptions()
//             )
//             .then((detection) => {
//               return detection ? detection.score : 0;
//             });

//           console.log("Face Probability:", probability);

//           if (probability > 0.7) {
//             setIsChecking(true);
//             captureImage();
//           }
//         }
//       }, 1000);
//       intervalIdRef.current = intervalId;
//     };

//     const captureImage = () => {
//       const canvas = document.createElement("canvas");
//       canvas.width = videoRef.current.videoWidth;
//       canvas.height = videoRef.current.videoHeight;
//       const ctx = canvas.getContext("2d");
//       ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
//       const imageData = canvas.toDataURL("image/jpeg");
//       imageRef.current.src = imageData;

//       axios
//         .post("http://localhost:5000/save-image", { image: imageData })
//         .then((response) => {
//           console.log(response.data.message);
//           setTimeout(() => {
//             setIsChecking(false);
//           }, 10000); // Set to stop checking after 10 seconds
//         })
//         .catch((error) => {
//           console.error("Error saving image:", error);
//           setIsChecking(false);
//         });
//     };

//     const handleLoadedData = () => {
//       faceMyDetect();
//     };

//     videoRef.current.addEventListener("loadeddata", handleLoadedData);

//     loadModels();

//     return () => {
//       if (videoRef.current) {
//         videoRef.current.removeEventListener("loadeddata", handleLoadedData);
//       }
//       stopVideo();
//       clearInterval(intervalIdRef.current);
//     };
//   }, [isChecking]);

//   return (
//     <div className="flex justify-between gap-4">
//       <div>{<QRCodeScanner />}</div>
//       <div className="myapp flex flex-col items-center">
//         <h1 className="text-2xl font-bold mb-4">Face Detection</h1>
//         <div className="relative w-[940px] h-[650px]">
//           <video
//             crossOrigin="anonymous"
//             ref={videoRef}
//             autoPlay
//             className="absolute top-0 left-0 w-full h-full object-cover transform -scale-x-100"
//           />
//           <canvas
//             ref={canvasRef}
//             width="940"
//             height="650"
//             className="absolute top-0 left-0"
//           />
//           <img
//             ref={imageRef}
//             style={{ display: "none" }}
//             alt="Mô tả của hình ảnh"
//           />
//           {isChecking && (
//             <div className="absolute top-0 left-0 w-full h-full flex justify-center items-center bg-black bg-opacity-75 text-white text-lg font-bold">
//               ĐANG KIỂM TRA...
//             </div>
//           )}
//         </div>
//       </div>
//       <div>
//         <CheckSuccess />
//       </div>
//     </div>
//   );
// };

// export default CaptureImage;



import React from 'react';

const Home = () => {
  return (
    <div className="flex  justify-center gap-4">
      <h1 className=''>Face Detection Stream</h1>
      <img className={"transform -scale-x-100"} src="http://127.0.0.1:5000/video_feed" alt="Video Stream" style={{ width: '45%' }} />
    </div>
  );
};

export default Home;
