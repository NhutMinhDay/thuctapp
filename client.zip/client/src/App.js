// import React, { useContext, useEffect } from "react";
// import { BrowserRouter, Routes, Route, useNavigate } from "react-router-dom";
// import Header from "./components/Hearder";
// import SignupUser from "./components/users/SignupUser";
// import Home from "./pages/Home";
// import Login from "./pages/Login";
// import QRCodeScanner from "./components/QRCodeScanner";
// import UserProfile from "./components/users/UserProfile";
// import { AuthContext } from "./components/users/AuthContext";

// function App() {
//   const navigate = useNavigate();

//   const { state } = useContext(AuthContext);
//   const { isLoggedIn } = state;

//   useEffect(() => {
//     if (isLoggedIn) {
//       navigate('./profile');
//     }
//   }, [isLoggedIn, navigate]);

//   return (
//       <BrowserRouter>
//         <Header />
//         <Routes>
//           <Route index element={<Home />} />

//           <Route path="/signup" element={<SignupUser />} />
//           <Route path="/qrscanner" element={<QRCodeScanner />} />
//           <Route path="/login" element={<Login />} />
//           <Route path="/profile" element={<UserProfile />} />
//         </Routes>
//       </BrowserRouter>
//   );
// }

// export default App;

import React, { useContext } from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Header from "./components/Hearder";
import SignupUser from "./components/users/SignupUser";
import Home from "./pages/Home";
import Login from "./pages/Login";
import QRCodeScanner from "./components/QRCodeScanner";
import UserProfile from "./components/users/UserProfile";
import { AuthContext } from "./components/users/AuthContext";
import CheckSuccess from "./components/CheckSuccess";

function App() {
  const { state } = useContext(AuthContext);
  const { isLoggedIn } = state;
  console.log(isLoggedIn);

  return (
    <BrowserRouter>
      <Header isLoggedIn={isLoggedIn}  />
      <Routes>
        <Route index element={<Home />} />
        <Route path="/signup" element={<SignupUser />} />
        <Route path="/qrscanner" element={<QRCodeScanner />} />
        <Route path="/login" element={<Login />} />
        <Route
          path="/profile"
          element={isLoggedIn ? <UserProfile /> : <Navigate to="/login" />}
        />
        <Route path="/checksuccess" element={<CheckSuccess/>}/>
      </Routes>

    </BrowserRouter>
  );
}

export default App;
