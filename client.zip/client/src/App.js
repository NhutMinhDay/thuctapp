import React, { useContext } from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Header from "./components/Hearder";
import SignupUser from "./components/users/SignupUser";
import Home from "./pages/Home";
import Login from "./pages/Login";
import UserProfile from "./components/users/UserProfile";
import { AuthContext } from "./components/users/AuthContext";
import CheckSuccess from "./components/CheckSuccess";
import ThongKe from "./components/ThongKe";
import CapScan from "./components/CapScan";

function App() {
  const { state } = useContext(AuthContext);
  const { isLoggedIn } = state;
  console.log(isLoggedIn);

  return (
    <BrowserRouter>
      <Header isLoggedIn={isLoggedIn}  />
      <Routes>
        <Route index element={<Home />} />
        <Route path="/signup" element={<SignupUser />} />
        <Route path="/login" element={<Login />} />
        <Route path="/thongke" element={<ThongKe/>} />
        <Route path="/chupanhanh" element={<CapScan/>} />
        <Route
          path="/profile"
          element={isLoggedIn ? <UserProfile /> : <Navigate to="/login" />}
        />
        <Route path="/checksuccess" element={<CheckSuccess/>}/>
      </Routes>

    </BrowserRouter>
  );
}

export default App;
