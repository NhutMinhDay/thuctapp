import React, { useContext, useState } from "react";
import { FaSearch } from "react-icons/fa";
import { Link } from "react-router-dom";
import { AuthContext } from "./users/AuthContext";

const Header = ({ isLoggedIn }) => {
  const { logout } = useContext(AuthContext);
  const [logoutMessage, setLogoutMessage] = useState("");

  const handleLogout = async () => {
    await logout();
    setLogoutMessage("Logout successful");
    alert("LOGOUT SUCCESSFUL!!!");
  };

  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-6 py-3">
        <div className="flex items-center justify-between">
          <div className="">
            <Link to={"/"}>
              <h1 className="font-bold text-sm sm:text-xl flex flex-wrap">
                <span className="text-slate-500">Face</span>
                <span className="text-slate-700">NMH</span>
              </h1>
            </Link>
          </div>
          <div className="flex items-center">
            <form className="hidden md:flex">
              <input
                type="text"
                placeholder="Search..."
                className="bg-gray-100 text-gray-800 rounded-l-full py-2 px-4 focus:outline-none"
              />
              <button className="bg-gray-100 hover:bg-gray-200 rounded-r-full focus:outline-none px-4 py-2">
                <FaSearch className="text-gray-800" />
              </button>
            </form>
            <ul className="flex items-center">
              <li>
                <Link
                  to={"/"}
                  className="text-gray-800 hover:text-gray-900 px-3 py-2 transition duration-300 ease-in-out transform hover:scale-105"
                >
                  Home
                </Link>
              </li>
              {!isLoggedIn && (
                <>
                  <li>
                    <Link
                      to={"/signup"}
                      className="text-gray-800 hover:text-gray-900 px-3 py-2 transition duration-300 ease-in-out transform hover:scale-105"
                    >
                      Sign Up
                    </Link>
                  </li>
                  <li>
                    <Link
                      to={"/login"}
                      className="text-gray-800 hover:text-gray-900 px-3 py-2 transition duration-300 ease-in-out transform hover:scale-105"
                    >
                      Login
                    </Link>
                  </li>
                </>
              )}
              {isLoggedIn && (
                <li className="ml-3">
                  <div className="relative">
                    <button
                      onClick={handleLogout}
                      className="text-gray-800 hover:text-gray-900 px-3 py-2 transition duration-300 ease-in-out transform hover:scale-105"
                    >
                      Logout
                    </button>
                  </div>
                </li>
              )}
            </ul>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;


// import React, { useContext, useState } from "react";
// import { FaSearch } from "react-icons/fa";
// import { Link } from "react-router-dom";
// import { AuthContext } from "./users/AuthContext";

// const Header = ({ isLoggedIn }) => {
//   const { logout } = useContext(AuthContext);
//   const [logoutMessage, setLogoutMessage] = useState("");

//   const handleLogout = async () => {
//     await logout();
//     setLogoutMessage("LogOut successfull");
//     alert("LOGOUT SUCCESSFULL!!!");
//   };
//   return (
//     <header className="bg-slate-200 shadow-md">
//       <div className="flex justify-between items-center max-w-6xl mx-auto p-3">
//         <Link to={"/"}>
//           <h1 className="font-bold text-sm sm:text-xl flex flex-wrap">
//             <span className="text-slate-500">Face</span>
//             <span className="text-slate-700">NMH</span>
//           </h1>
//         </Link>
//         <form className="bg-slate-100 p-3 rounded-lg flex items-center">
//           <input
//             type="text"
//             placeholder="Search..."
//             className="bg-transparent focus:outline-none w-24 sm:w-64"
//           />
//           <FaSearch className="text-slate-600" />
//         </form>

//         <ul className="flex gap-4">
//           <Link to={"/"} className="text-slate-700 hover:underline font-mono font-bold">
//             <li>Home</li>
//           </Link>
//           {!isLoggedIn && (
//             <>
//               <Link to={"/signup"} className="text-slate-700 hover:underline">
//                 <li>Sign Up</li>
//               </Link>
//               <Link to={"/login"} className="text-slate-700 hover:underline">
//                 <li>Login</li>
//               </Link>
//             </>
//           )}
//           {isLoggedIn && (
//             <div className="flex justify-between gap-4 font-mono font-bold">
//               <Link to={"/profile"} className="text-slate-700 hover:underline">
//                 <li>Profile</li>
//               </Link>
//               <Link className="text-slate-700 hover:underline">
//                 <button onClick={handleLogout}>Logout</button>
//               </Link>
//             </div>
//           )}
//         </ul>
//       </div>
//     </header>
//   );
// };

// export default Header;
