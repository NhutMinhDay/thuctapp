import React, { useContext} from "react";
import { FaSearch } from "react-icons/fa";
import { Link } from "react-router-dom";
import { AuthContext } from "./users/AuthContext";

const Header = ({ isLoggedIn }) => {
  const { logout } = useContext(AuthContext);
  const { state } = useContext(AuthContext);
  const { userInfo } = state;
  const handleLogout = async () => {
    await logout();
  };

  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-6 py-3">
        <div className="flex items-center justify-between">
          <div className="">
            <Link to={"/"}>
              <h1 className="font-bold text-sm sm:text-xl flex flex-wrap">
                <span className="text-slate-500">Face</span>
                <span className="text-slate-700">NMH</span>
              </h1>
            </Link>
          </div>
          <div className="flex items-center">
            <form className="hidden md:flex">
              <input
                type="text"
                placeholder="Search..."
                className="bg-gray-100 text-gray-800 rounded-l-full py-2 px-4 focus:outline-none"
              />
              <button className="bg-gray-100 hover:bg-gray-200 rounded-r-full focus:outline-none px-4 py-2">
                <FaSearch className="text-gray-800" />
              </button>
            </form>
            <ul className="flex items-center">
              <li>
                <Link
                  to={"/"}
                  className="text-gray-800 hover:text-gray-900 px-3 py-2 transition duration-300 ease-in-out transform hover:scale-105"
                >
                  Trang Chủ
                </Link>
              </li>
              {!isLoggedIn && (
                <>
                  <li>
                    <Link
                      to={"/signup"}
                      className="text-gray-800 hover:text-gray-900 px-3 py-2 transition duration-300 ease-in-out transform hover:scale-105"
                    >
                      Đăng Kí
                    </Link>
                  </li>
                  <li>
                    <Link
                      to={"/login"}
                      className="text-gray-800 hover:text-gray-900 px-3 py-2 transition duration-300 ease-in-out transform hover:scale-105"
                    >
                      Đăng Nhập
                    </Link>
                  </li>
                </>
              )}
              {isLoggedIn && (
                <li className="ml-3">
                  <div className="relative flex justify-center">
                    <Link to={"./profile"} className="">
                      <img
                        src={userInfo.IMAGE_BETWEEN}
                        alt="Profile"
                        className="w-12 h-12 rounded-full border-3 border-indigo-400 shadow-lg transition-transform transform hover:scale-110"
                      />
                    </Link>
                    <button
                      onClick={handleLogout}
                      className="text-gray-800 hover:text-gray-900 px-3 py-2 transition duration-300 ease-in-out transform hover:scale-105"
                    >
                      Đăng Xuất
                    </button>
                  </div>
                </li>
              )}
            </ul>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
