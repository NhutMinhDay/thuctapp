import React, { useState, useEffect } from 'react';
import axios from 'axios';

const CheckSuccess = () => {
  const [distances, setDistances] = useState({});
  const [result, setResult] = useState('');
  console.log(result, distances)
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('http://127.0.0.1:5000/print-vectors');
        setDistances(response.data.distances);
        setResult(response.data.result);
        setLoading(false);
      } catch (error) {
        setError(error.message);
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="text-lg">Đang tải...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="text-red-500">Lỗi: {error}</div>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto mt-24 p-5 bg-cyan-50 rounded-lg shadow-lg">
      <h1 className="text-2xl font-bold mb-4 text-slate-800">Kết quả kiểm tra:</h1>
      <p className="text-xl text-red-600 font-semibold">{result}</p>
      <ul className="mt-6">
        {Object.entries(distances).map(([key, value]) => (
          <li key={key} className="mb-2 text-gray-800">
            {key}: {value}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default CheckSuccess;