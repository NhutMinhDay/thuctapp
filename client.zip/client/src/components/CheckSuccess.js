import React, { useState, useEffect } from "react";
import axios from "axios";

function CheckSuccess() {
  const [data, setData] = useState({
    TenNhanVien: "",
    distances: [],
    result: "",
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;

    const fetchData = async () => {
      try {
        const response = await axios.get("http://127.0.0.1:5000/check-status");
        if (isMounted) {
          setData(response.data);
          setLoading(false);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        if (isMounted) {
          setLoading(false);
        }
      }
    };
    fetchData();
    const interval = setInterval(fetchData, 5000);

    return () => {
      clearInterval(interval);
      isMounted = false;
    };
  }, []);

  if (loading) {
    return (
      <div className="max-w-md mx-auto mt-2 p-5 rounded-lg shadow-lg">
        <div className="text-center">Loading...</div>
      </div>
    );
  }

  return (
    <div className="mx-auto mt-1 p-5 rounded-lg shadow-lg">

    
      <h1 className="text-xs font-bold mb-1 text-slate-800">
        KẾT QUẢ ĐIỂM DANH:
      </h1>
      <div className="bg-white rounded-lg p-2 shadow-md mb-1">
        <p className="text-xs text-gray-600 font-semibold mb-0">
          Tên nhân viên:
        </p>
        <p className="text-sm text-red-600 font-bold">{data.TenNhanVien}</p>
      </div>
      <div
        className={`bg-white rounded-lg p-2 shadow-md mb-1 ${
          data.result.includes("thành công")
            ? "border-green-500"
            : "border-red-500"
        }`}
      >
        <p className="text-xs text-gray-600 font-semibold mb-0">Kết quả:</p>
        <p
          className={`text-sm font-bold ${
            data.result.includes("thành công")
              ? "text-green-600"
              : "text-red-600"
          }`}
        >
          {data.result}
        </p>
      </div>
    </div>
  );
}

export default CheckSuccess;





// import React, { useState, useEffect } from "react";
// import axios from "axios";

// function CheckSuccess() {
//   const [data, setData] = useState({ result: '' });
//   const [loading, setLoading] = useState(true);

//   useEffect(() => {
//     const fetchData = async () => {
//       try {
//         const response = await axios.get("http://127.0.0.1:5000/check-status");
//         setData(response.data);
//         setLoading(false);
//       } catch (error) {
//         console.error("Error fetching data:", error);
//         setLoading(false); // Đặt loading thành false ngay cả khi có lỗi
//       }
//     };

//     fetchData(); // Gọi fetchData ngay lập tức

//     const interval = setInterval(fetchData, 5000); // Gọi fetchData mỗi 5 giây
//     return () => clearInterval(interval);
//   }, []);

//   console.log(data);

//   if (loading) {
//     return (
//       <div className="max-w-md mx-auto mt-2 p-5 bg-cyan-50 rounded-lg shadow-lg">
//         <div className="text-center">Loading...</div>
//       </div>
//     );
//   }

//   return (
//     <div className="mx-auto mt-1 p-5 bg-cyan-50 rounded-lg shadow-lg">
//       <h1 className="text-lg font-bold mb-1 text-slate-800">
//         KẾT QUẢ ĐIỂM DANH:
//       </h1>
//       <p className="text-sm text-red-600 font-semibold">{data.TenNhanVien}</p>
//       <p className="text-sm text-red-600 font-semibold">{data.result}</p>
//     </div>
//   );
// }

// export default CheckSuccess;




// import React, { useState, useEffect } from "react";
// import axios from "axios";

// function CheckSuccess() {
//   const [data, setData] = useState({
//     TenNhanVien: "",
//     distances: [],
//     result: "",
//   });
//   const [loading, setLoading] = useState(true);
//   const [showNotification, setShowNotification] = useState(false);

//   useEffect(() => {
//     const fetchData = async () => {
//       try {
//         const response = await axios.get("http://127.0.0.1:5000/check-status");
//         setData(response.data);
//         setLoading(false);
//         setShowNotification(true);

//         // Automatically hide notification after 5 seconds
//         setTimeout(() => {
//           setShowNotification(false);
//         }, 5000);
//       } catch (error) {
//         console.error("Error fetching data:", error);
//         setLoading(false);
//         setShowNotification(true);

//         // Automatically hide notification after 5 seconds
//         setTimeout(() => {
//           setShowNotification(false);
//         }, 5000);
//       }
//     };

//     fetchData();

//     const interval = setInterval(fetchData, 5000);
//     return () => clearInterval(interval);
//   }, []);

//   if (loading) {
//     return (
//       <div className="max-w-md mx-auto mt-2 p-5 bg-cyan-50 rounded-lg shadow-lg">
//         <div className="text-center">Loading...</div>
//       </div>
//     );
//   }

//   return (
//     <div className="mx-auto mt-1 p-5 bg-cyan-50 rounded-lg shadow-lg">
//       <h1 className="text-xs font-bold mb-1 text-slate-800">
//         KẾT QUẢ ĐIỂM DANH:
//       </h1>
//       <div className="bg-white rounded-lg p-2 shadow-md mb-1">
//         <p className="text-xs text-gray-600 font-semibold mb-0">
//           Tên nhân viên:
//         </p>
//         <p className="text-sm text-red-600 font-bold">{data.TenNhanVien}</p>
//       </div>
//       <div
//         className={`bg-white rounded-lg p-2 shadow-md mb-1 ${
//           data.result.includes("thành công")
//             ? "border-green-500"
//             : "border-red-500"
//         }`}
//       >
//         <p className="text-xs text-gray-600 font-semibold mb-0">Kết quả:</p>
//         <p
//           className={`text-sm font-bold ${
//             data.result.includes("thành công")
//               ? "text-green-600"
//               : "text-red-600"
//           }`}
//         >
//           {data.result}
//         </p>
//       </div>

//       {showNotification && (
//         <div
//           className={`fixed top-0 inset-x-0 p-4 transition-opacity ${
//             showNotification ? "opacity-100" : "opacity-0"
//           } ${
//             data.result.includes("thành công") ? "bg-green-500" : "bg-red-500"
//           } text-white text-center`}
//         >
//           {data.result.includes("thành công")
//             ? "Điểm danh thành công!"
//             : "Điểm danh thất bại!"}
//         </div>
//       )}
//     </div>
//   );
// }

// export default CheckSuccess;
