import React, { useEffect, useRef, useState } from "react";
import * as faceapi from "face-api.js";
import axios from "axios";
import jsQR from "jsqr";
import CheckSuccess from "./CheckSuccess";
import ThongKe from "./ThongKe";

const CapScan = () => {
  const videoRef = useRef();
  const canvasRef = useRef();
  const imageRef = useRef();
  const streamRef = useRef(null);
  const animationFrameIdRef = useRef(null);
  const [isCapturing, setIsCapturing] = useState(false);
  const [qrCodeData, setQrCodeData] = useState(null);
  const [warningMessage, setWarningMessage] = useState("");

  useEffect(() => {
    const loadModels = async () => {
      await Promise.all([
        faceapi.nets.tinyFaceDetector.loadFromUri("/models"),
        faceapi.nets.faceLandmark68Net.loadFromUri("/models"),
        faceapi.nets.faceExpressionNet.loadFromUri("/models"),
      ]);
      startVideo();
    };

    const startVideo = () => {
      navigator.mediaDevices
        .getUserMedia({ video: true })
        .then((currentStream) => {
          streamRef.current = currentStream;
          videoRef.current.srcObject = currentStream;
        })
        .catch((err) => {
          // console.log(err);
        });
    };

    const detectFaceAndQR = async () => {
      if (isCapturing) {
        animationFrameIdRef.current = requestAnimationFrame(detectFaceAndQR);
        return;
      }

      const videoElement = videoRef.current;
      if (!videoElement || videoElement.readyState !== 4) {
        animationFrameIdRef.current = requestAnimationFrame(detectFaceAndQR);
        return;
      }

      const detections = await faceapi
        .detectAllFaces(videoElement, new faceapi.TinyFaceDetectorOptions())
        .withFaceLandmarks()
        .withFaceExpressions();

      const canvas = faceapi.createCanvasFromMedia(videoElement);
      faceapi.matchDimensions(canvas, {
        width: 940,
        height: 528,
      });

      const resized = faceapi.resizeResults(detections, {
        width: 940,
        height: 528,
      });

      const context = canvasRef.current.getContext("2d");
      context.clearRect(0, 0, canvas.width, canvas.height);

      faceapi.draw.drawDetections(canvas, resized);
      faceapi.draw.drawFaceExpressions(canvas, resized);

      context.drawImage(canvas, 0, 0);

      if (resized.length > 0) {
        const faceBox = resized[0].detection.box;
        const faceCenterX = faceBox.x + faceBox.width / 2;
        const faceCenterY = faceBox.y + faceBox.height / 2;
        const frameCenterX = 940 / 2;
        const frameCenterY = 528 / 2;

        const isFaceInCenter =
          Math.abs(faceCenterX - frameCenterX) < 100 &&
          Math.abs(faceCenterY - frameCenterY) < 100;

        if (isFaceInCenter) {
          const canvasForQR = document.createElement("canvas");
          canvasForQR.width = videoRef.current.videoWidth;
          canvasForQR.height = videoRef.current.videoHeight;
          const ctxForQR = canvasForQR.getContext("2d");
          ctxForQR.drawImage(
            videoRef.current,
            0,
            0,
            canvasForQR.width,
            canvasForQR.height
          );
          const imageDataArray = ctxForQR.getImageData(
            0,
            0,
            canvasForQR.width,
            canvasForQR.height
          );
          const qrCode = jsQR(
            imageDataArray.data,
            imageDataArray.width,
            imageDataArray.height
          );

          if (qrCode) {
            const probability = await faceapi
              .detectSingleFace(
                videoElement,
                new faceapi.TinyFaceDetectorOptions()
              )
              .then((detection) => {
                return detection ? detection.score : 0;
              });

            if (probability > 0.8) {
              setIsCapturing(true);
              setWarningMessage(""); // Clear any existing warning message
              captureImage(qrCode.data);
            }
          } else {
            setWarningMessage("Không có mã QR.");
          }
        }
      }

      animationFrameIdRef.current = requestAnimationFrame(detectFaceAndQR);
    };

    const captureImage = async (qrCodeData) => {
      const canvas = document.createElement("canvas");
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      const ctx = canvas.getContext("2d");
      ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
      const imageData = canvas.toDataURL("image/jpeg");
      imageRef.current.src = imageData;
    
      console.log("Image Data");
      console.log("QR Code Data:", qrCodeData);
    
      setQrCodeData(qrCodeData);
    
      try {
        const response = await axios.post("http://localhost:5000/save-image", {
          image: imageData,
          data: qrCodeData,
        });
    
        setIsCapturing(false);
        setQrCodeData(null); // Reset qrCodeData to null after successful capture
      } catch (error) {
        setIsCapturing(false);
      }
    };
    

    const handleLoadedData = () => {
      animationFrameIdRef.current = requestAnimationFrame(detectFaceAndQR);
    };

    videoRef.current.addEventListener("loadeddata", handleLoadedData);

    loadModels();

    return () => {
      if (videoRef.current) {
        videoRef.current.removeEventListener("loadeddata", handleLoadedData);
      }
      cancelAnimationFrame(animationFrameIdRef.current);
    };
  }, [isCapturing]);
  return (
    <>
      <div className="pl-1 ml-1">
        <div className="flex justify-center flex-col ml-4">
          <h1 className="text-2xl font-bold mb-4 mt-2 uppercase">
            Kiểm tra gương mặt
          </h1>

          <div className="relative w-[940px] h-[528px]">
            <video
              crossOrigin="anonymous"
              ref={videoRef}
              autoPlay
              className="absolute top-0 left-0 w-full h-full object-cover "
            />
            <div className="absolute top-0 left-0 w-full h-full flex items-center justify-center">
              {/* Khung hình vuông */}
              <div className="w-60 h-60 border-4 border-red-500 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"></div>
            </div>
            <canvas
              ref={canvasRef}
              width="940"
              height="528"
              className="absolute top-0 left-0"
            />
            <img
              ref={imageRef}
              style={{ display: "none" }}
              alt="Mô tả của hình ảnh"
            />
          </div>
        </div>
      </div>

      <div className="flex justify-end absolute top-8 right-3 mt-12 mr-1">
        <ThongKe />
      </div>
      <div className="flex justify-center w-1/2 ml-5 mt-5 space-x-4">
        <div className="m-2 bg-white border border-gray-300 rounded-lg shadow-lg p-4 w-full">
          {qrCodeData ? (
            <div className="bg-white rounded-lg p-2 shadow-md mb-1">
              <h2 className="text-sm font-bold">Mã QR:</h2>
              <p>{qrCodeData}</p>
            </div>
          ) : (
            <h2 className="text-xl font-bold">Không có mã QR.</h2>
          )}
          <div>
            {warningMessage && (
              <div className="bg-yellow-200 animate-pulse text-yellow-800 border border-yellow-300 rounded-lg p-4 w-full">
                <p>{warningMessage}</p>
              </div>
            )}
          </div>
        </div>
        <div className="m-2 bg-white border border-gray-300 rounded-lg shadow-lg p-4 w-full">
          <CheckSuccess />
        </div>
      </div>
    </>
  );
};

export default CapScan;
