import React, { useState, useEffect } from "react";
import axios from "axios";
import { format } from "date-fns";
import { vi } from "date-fns/locale";

const ThongKe = () => {
  const [thongKeData, setThongKeData] = useState([]);
  const currentDate = new Date();

  const fetchData = async () => {
    try {
      const response = await axios.get(
        "http://127.0.0.1:5000/api/diemdanh/thongkengaylam"
      );
      setThongKeData(response.data);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    fetchData(); // Fetch data when component mounts

    const intervalId = setInterval(fetchData, 5000); // Fetch data every 5 seconds

    return () => clearInterval(intervalId); // Cleanup interval on unmount
  }, []);

  const getSession = (item) => {
    const currentTime = new Date();
    const currentHours = currentTime.getHours();
    const currentMinutes = currentTime.getMinutes();
    console.log(currentHours, currentMinutes)
    // Thời gian vào sáng từ 6h30 đến 7h
    if ((currentHours === 6 && currentMinutes >= 30) || (currentHours === 7 && currentMinutes <= 0)) {
      return {
        time: item.THOIGIAN_VAO_SANG,
        session: "Buổi Sáng (Vào)"
      };
    }
    // Thời gian ra sáng từ 11h đến 11h30
    else if (currentHours === 11 && currentMinutes >= 0 && currentMinutes <= 30) {
      return {
        time: item.THOIGIAN_RA_SANG,
        session: "Buổi Sáng (Ra)"
      };
    }

    // Thời gian vào chiều từ 13h15 đến 13h45
    else if ((currentHours === 13 && currentMinutes >= 15) || (currentHours === 13 && currentMinutes <= 45)) {
      return {
        time: item.THOIGIAN_VAO_CHIEU,
        session: "Buổi Chiều (Vào)"
      };
    }
    // Thời gian ra chiều từ 17h đến 17h30
    else if (currentHours === 17 && currentMinutes >= 0 && currentMinutes <= 30) {
      return {
        time: item.THOIGIAN_RA_CHIEU,
        session: "Buổi Chiều (Ra)"
      };
    } else {
      return {
        time: "",
        session: ""
      };
    }
  };

  return (
    <div className="w-[640px] h-screen overflow-hidden">
      <h1 className="text-lg font-bold mb-4">Thống Kê Điểm Danh Ngày Làm</h1>
      <div className="w-full flex justify-end mb-1">
        <div className="w-auto text-center rounded-md border border-gray-400 p-2 whitespace-nowrap">
          {format(currentDate, "dd/MM/yyyy", { locale: vi })}
        </div>
      </div>
      <div className="overflow-x-auto overflow-y-auto">
        <table className="w-full text-xs border-collapse border border-gray-400">
          <thead>
            <tr className="bg-gray-200">
              <th className="border border-gray-400 px-4 py-2">ID Nhân Viên</th>
              <th className="border border-gray-400 px-4 py-2">Thời gian</th>
              <th className="border border-gray-400 px-4 py-2">Buổi</th>
            </tr>
          </thead>
          <tbody>
            {thongKeData.map((item) => (
              <tr key={item.DiemDanhID} className="hover:bg-gray-100 text-center">
                <td className="border border-gray-400 px-4 py-2 whitespace-nowrap">
                  {item.ID_NV}
                </td>
                <td className="border border-gray-400 px-4 py-2 whitespace-nowrap">
                  {getSession(item).time}
                </td>
                <td className="border border-gray-400 px-4 py-2 whitespace-nowrap">
                  {getSession(item).session}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ThongKe;
