// import React, { useState, useRef, useEffect } from 'react';
// import axios from 'axios';
// import QrScanner from 'react-qr-scanner';

// const QRCodeScanner = () => {
//   const [data, setData] = useState('Chưa có kết quả');
//   const [scanning, setScanning] = useState(true);
//   const [capturedImage, setCapturedImage] = useState(null);
//   const scannerRef = useRef(null);
//   const videoRef = useRef(null);

//   const handleScan = (result) => {
//     if (result && scanning) {
//       setData(result.text);
//       setScanning(false); // Dừng quét
//       captureImage(); // Chụp hình ảnh từ video stream
//       axios.post('http://localhost:5000/scan', { data: result.text })
//         .then(response => {
//           console.log(response.data);
//         })
//         .catch(error => {
//           console.error('Lỗi khi gửi dữ liệu đến backend:', error);
//         });

//       // Đợi 10 giây trước khi cho phép quét tiếp
//       setTimeout(() => {
//         setScanning(true); // Cho phép quét lại
//         setCapturedImage(null); // Xóa hình ảnh đã chụp sau khi chờ xong
//       }, 10000);
//     }
//   };

//   const handleError = (err) => {
//     console.error(err);
//   };

//   const captureImage = () => {
//     const video = videoRef.current?.querySelector('video');
//     if (video) {
//       const canvas = document.createElement('canvas');
//       canvas.width = video.videoWidth;
//       canvas.height = video.videoHeight;
//       const ctx = canvas.getContext('2d');
//       ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
//       const imageData = canvas.toDataURL('image/png');
//       setCapturedImage(imageData);
//     }
//   };

//   const previewStyle = {
//     height: 240,
//     width: 320,
//   };

//   useEffect(() => {
//     const scanner = scannerRef.current;
//     if (scanner) {
//       scanner.start();
//     }

//     return () => {
//       if (scanner) {
//         scanner.stop();
//       }
//     };
//   }, []);

//   return (
//     <div >
//       <h1>Máy Quét QR Code</h1>
//       <div className='transform -scale-x-100'>
//       <QrScanner
        
//         ref={scannerRef}
//         delay={300}
//         style={previewStyle}
//         onError={handleError}
//         onScan={handleScan}
//         facingMode="environment"
//         legacyMode={false}
//         videoRef={videoRef}
//       />
//       {!scanning && capturedImage && (
//         <img src={capturedImage} alt="QR code captured" style={previewStyle} />
//       )}
      
//       </div>
//       <p>{data}</p>
//     </div>
//   );
// };

// export default QRCodeScanner;


import React, { useState, useRef, useEffect } from 'react';
import axios from 'axios';
import QrScanner from 'react-qr-scanner';

const QRCodeScanner = () => {
  const [data, setData] = useState('Chưa có kết quả');
  const [scanning, setScanning] = useState(true);
  const [capturedImage, setCapturedImage] = useState(null);
  const scannerRef = useRef(null);
  const videoRef = useRef(null);

  const handleScan = (result) => {
    if (result && scanning) {
      setData(result.text);
      setScanning(false); // Dừng quét
      captureImage(); // Chụp hình ảnh từ video stream
      axios.post('http://localhost:5000/scan', { data: result.text })
        .then(response => {
          console.log(response.data);
        })
        .catch(error => {
          console.error('Lỗi khi gửi dữ liệu đến backend:', error);
        });

      // Đợi 10 giây trước khi cho phép quét tiếp
      setTimeout(() => {
        setScanning(true); // Cho phép quét lại
        setCapturedImage(null); // Xóa hình ảnh đã chụp sau khi chờ xong
      }, 10000);
    }
  };

  const handleError = (err) => {
    console.error(err);
  };

  const captureImage = () => {
    const video = videoRef.current?.querySelector('video');
    if (video) {
      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const imageData = canvas.toDataURL('image/png');
      setCapturedImage(imageData);
    }
  };

  useEffect(() => {
    const scanner = scannerRef.current;
    if (scanner) {
      scanner.start();
    }

    return () => {
      if (scanner) {
        scanner.stop();
      }
    };
  }, []);

  return (
    <div className="flex flex-col items-center justify-center mt-24 p-2">
      <h1 className="text-3xl font-bold mb-2">Máy Quét QR Code</h1>
      <div className="relative w-80 h-66 transform -scale-x-100">
        <QrScanner
          ref={scannerRef}
          delay={300}
          style={{ width: '100%', height: '100%' }}
          onError={handleError}
          onScan={handleScan}
          facingMode="environment"
          legacyMode={false}
          videoRef={videoRef}
        />
        {!scanning && capturedImage && (
          <img src={capturedImage} alt="QR code captured" className="absolute inset-0 object-cover w-full h-full" />
        )}
      </div>
      <p className="mt-4">{data}</p>
    </div>
  );
};

export default QRCodeScanner;
