import React, { useContext, useState } from "react";
import { AuthContext } from "./AuthContext";

const UserProfile = () => {
  const { state } = useContext(AuthContext);
  const { isLoggedIn, userInfo } = state;
  const [showImages, setShowImages] = useState(false);

  if (!isLoggedIn) {
    return <p className="text-center text-white text-lg">Bạn chưa đăng nhập</p>;
  }

  const toggleImages = () => {
    setShowImages(!showImages);
  };

  const getGenderText = () => {
    return userInfo.GIOITINH_NV === 1 ? "Nam" : "Nữ";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-500 via-cyan-500 to-pink-600 flex flex-col items-center justify-center text-slate-800 font-semibold p-4">
      <div className="mt-6 py-5 px-8 bg-white rounded-lg shadow-xl w-full max-w-md transform transition-transform hover:scale-105">
        <h2 className="text-4xl mb-6 text-center text-indigo-700 font-bold">
          Xin chào
        </h2>
        <div className="flex flex-col items-center mb-6">
          <img
            src={userInfo.IMAGE_BETWEEN}
            alt="Profile"
            className="w-40 h-40 rounded-full mb-5 border-4 border-indigo-400 shadow-lg transition-transform transform hover:scale-110"
          />
          <p className="uppercase text-lg text-indigo-700">{userInfo.TEN_NV}</p> {/* Tên dưới hình đại diện */}
          <button
            onClick={toggleImages}
            className="bg-indigo-600 text-white px-5 py-3 rounded-full shadow-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-opacity-50 transition-colors mt-2"
          >
            {showImages ? "Ẩn Ảnh" : "Hiển Thị Ảnh"}
          </button>
        </div>
        {showImages && (
          <div className="grid grid-cols-2 gap-4 mb-6 animate-fade-in">
            <img
              src={userInfo.IMAGE_BETWEEN}
              alt="Top"
              className="w-full h-32 object-cover rounded-lg shadow-md transition-transform transform hover:scale-105"
            />
            <img
              src={userInfo.IMAGE_TOP}
              alt="Top"
              className="w-full h-32 object-cover rounded-lg shadow-md transition-transform transform hover:scale-105"
            />
            <img
              src={userInfo.IMAGE_BOTTOM}
              alt="Bottom"
              className="w-full h-32 object-cover rounded-lg shadow-md transition-transform transform hover:scale-105"
            />
            <img
              src={userInfo.IMAGE_LEFT}
              alt="Left"
              className="w-full h-32 object-cover rounded-lg shadow-md transition-transform transform hover:scale-105"
            />
            <img
              src={userInfo.IMAGE_RIGHT}
              alt="Right"
              className="w-full h-32 object-cover rounded-lg shadow-md transition-transform transform hover:scale-105"
            />
          </div>
        )}
        <div className="space-y-4">
          <p className="text-lg text-indigo-700 tracking-wide">
            <span className="font-bold">Mã Nhân viên:</span> {userInfo.ID_NV}
          </p>
          <p className="text-lg text-indigo-700 tracking-wide">
            <span className="font-bold">Địa Chỉ:</span> {userInfo.DIACHI_NV}
          </p>
          <p className="text-lg text-indigo-700 tracking-wide">
            <span className="font-bold">Email:</span> {userInfo.EMAIL_NV}
          </p>
          <p className="text-lg text-indigo-700 tracking-wide">
            <span className="font-bold">Giới Tính:</span> {getGenderText()}
          </p>
          <p className="text-lg text-indigo-700 tracking-wide">
            <span className="font-bold">Ngày Sinh:</span> {userInfo.NGAYSINH_NV}
          </p>
          <p className="text-lg text-indigo-700 tracking-wide">
            <span className="font-bold">SĐT:</span> {userInfo.SDT_NV}
          </p>
        </div>
      </div>
    </div>
  );
};

export default UserProfile;

