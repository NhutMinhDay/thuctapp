import React, { useContext } from "react";
import { AuthContext } from "./AuthContext";

const UserProfile = () => {
  const { state } = useContext(AuthContext);
  const { isLoggedIn, userInfo } = state;

  if (!isLoggedIn) {
    return <p>Bạn chưa đăng nhập</p>;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-500 to-indigo-600 flex items-baseline justify-center text-slate-800 font-semibold">
      <div className="mt-24 p-8 bg-white rounded-lg shadow-lg">
        <h2 className="text-2xl mb-4">Welcome, {userInfo.TEN_NV}</h2>
        <p className="text-lg">ID Nhân viên: {userInfo.ID_NV}</p>
        <p className="text-lg">Địa Chỉ Nhân viên: {userInfo.DIACHI_NV}</p>
        <p className="text-lg">Email Nhân viên: {userInfo.EMAIL_NV}</p>
        <p className="text-lg">Giới Tính Nhân viên: {userInfo.GIOITINH_NV}</p>
        <p className="text-lg">Ngày Sinh Nhân viên: {userInfo.NGAYSINH_NV}</p>
        <p className="text-lg">SĐT Nhân viên: {userInfo.SDT_NV}</p>
        
      </div>
    </div>
  );
};

export default UserProfile;
