
import React, { useState, useEffect, useRef } from "react";
import axios from "axios";
import md5 from "md5";
import Webcam from "react-webcam";
import { useNavigate } from "react-router-dom";

const defaultAvatarUrl = "https://i.pinimg.com/736x/bc/43/98/bc439871417621836a0eeea768d60944.jpg"; // URL của hình ảnh mặc định

function SignupUser() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    id_nv: "",
    ma_qr: null,
    ten_nv: "",
    diachi_nv: "",
    email_nv: "",
    sdt_nv: "",
    gioitinh_nv: "1",
    ngaysinh_nv: "",
    username: "",
    password: "",
    trangthai_taikhoan: "1",
    thoigian_tao: "",
    thoigian_xoa: null,
    image_top: "",
    image_bottom: "",
    image_left: "",
    image_right: "",
    image_between: "",
  });
  const webcamRef = useRef(null);
  const [currentImageType, setCurrentImageType] = useState("");
  const [recognitionResult, setRecognitionResult] = useState({});

  useEffect(() => {
    const currentDateTime = new Date().toISOString().slice(0, 16);
    setFormData((prevData) => ({ ...prevData, thoigian_tao: currentDateTime }));
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleGenderChange = (e) => {
    const { value } = e.target;
    setFormData({ ...formData, gioitinh_nv: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const hashedPassword = md5(formData.password);
    const submitData = { ...formData, password: hashedPassword };
    try {
      const response = await axios.post(
        "http://localhost:5000/register",
        submitData
      );
      // alert(response.data.message);
      navigate("/login");
    } catch (error) {
      console.error("There was an error!", error);
    }
  };

  const captureImage = async (imageType) => {
    setCurrentImageType(imageType);
    const imageSrc = webcamRef.current.getScreenshot();
    if (imageSrc) {
      try {
        const formData = new FormData();
        formData.append("image", dataURItoBlob(imageSrc));
        const response = await axios.post(
          "http://localhost:5000/verify-face",
          formData,
          {
            headers: {
              "Content-Type": "multipart/form-data",
            },
          }
        );

        if (response.data.success) {
          // Save image to formData
          setFormData((prevData) => ({
            ...prevData,
            [imageType]: imageSrc,
          }));
          setRecognitionResult(response.data); // Update recognition result
          // alert("Khuôn mặt được nhận dạng.");
        } else {
          // alert("Không phát hiện thấy khuôn mặt nào, vui lòng thử lại.");
        }
      } catch (error) {
        console.error("Recognition error:", error);
        // alert("Không phát hiện thấy khuôn mặt nào, vui lòng thử lại.");
      }
    } else {
      // alert("Không thể chụp ảnh, vui lòng thử lại.");
    }
  };

  const dataURItoBlob = (dataURI) => {
    let byteString;
    if (dataURI.split(",")[0].indexOf("base64") >= 0)
      byteString = atob(dataURI.split(",")[1]);
    else byteString = unescape(dataURI.split(",")[1]);

    const mimeString = dataURI.split(",")[0].split(":")[1].split(";")[0];
    const ia = new Uint8Array(byteString.length);
    for (let i = 0; i < byteString.length; i++) {
      ia[i] = byteString.charCodeAt(i);
    }

    return new Blob([ia], { type: mimeString });
  };

  return (
    <div className="w-full flex justify-center m-5 p-5 rounded-xl bg-gray-100">
      <div className="flex flex-nowrap">
        <form
          onSubmit={handleSubmit}
          className="bg-white w-2/5 p-10 rounded shadow-md my-8 mx-4"
        >
          <h1 className="text-3xl uppercase font-bold mb-8 text-center">
            Đăng kí tài khoản
          </h1>
          {[
            {
              name: "id_nv",
              type: "text",
              placeholder: "Mã Nhân Viên",
              label: "Mã Nhân Viên",
            },
            {
              name: "ten_nv",
              type: "text",
              placeholder: "Họ và Tên",
              label: "Họ & Tên",
            },
            {
              name: "diachi_nv",
              type: "text",
              placeholder: "Địa chỉ",
              label: "Địa chỉ",
            },
            {
              name: "email_nv",
              type: "email",
              placeholder: "Email",
              label: "Email",
            },
            {
              name: "sdt_nv",
              type: "text",
              placeholder: "Số Điện Thoại",
              label: "SĐT",
            },
            { name: "ngaysinh_nv", type: "date", label: "Ngày Sinh" },
            {
              name: "username",
              type: "text",
              placeholder: "Tên tài khoản",
              label: "Tên tài khoản",
            },
            {
              name: "password",
              type: "password",
              placeholder: "Mật khẩu",
              label: "Mật khẩu",
            },
          ].map((input) => (
            <div key={input.name} className="my-4 flex flex-col">
              <label className="mb-2 font-medium">
                {input.label}
                <input
                  type={input.type}
                  name={input.name}
                  placeholder={input.placeholder}
                  value={formData[input.name]}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-2 border rounded focus:outline-none focus:ring focus:border-blue-300"
                />
              </label>
            </div>
          ))}
          <div className="mb-4 flex gap-5">
            <label className="block mb-1 font-medium">Giới tính</label>
            <div className="flex items-center">
              <label className="mr-4">
                <input
                  type="radio"
                  name="gioitinh_nv"
                  value="1"
                  checked={formData.gioitinh_nv === "1"}
                  onChange={handleGenderChange}
                  className="mr-2"
                />
                Nam
              </label>
              <label>
                <input
                  type="radio"
                  name="gioitinh_nv"
                  value="0"
                  checked={formData.gioitinh_nv === "0"}
                  onChange={handleGenderChange}
                  className="mr-2"
                />
                Nữ
              </label>
            </div>
          </div>
          <input
            type="hidden"
            name="trangthai_taikhoan"
            value={formData.trangthai_taikhoan}
          />
          <input
            type="hidden"
            name="thoigian_tao"
            value={formData.thoigian_tao}
          />
          <input
            type="hidden"
            name="thoigian_xoa"
            value={formData.thoigian_xoa}
          />
          <button
            type="submit"
            className="w-full bg-green-500 text-white px-3 py-2 rounded hover:bg-green-600 focus:outline-none"
          >
            Đăng kí tài khoản
          </button>
        </form>

        <div className="w-2/3 flex flex-col items-center mt-8">
          <Webcam
            audio={false}
            screenshotFormat="image/jpeg"
            ref={webcamRef}
            className="rounded mb-4 transform -scale-x-100"
          />
          <div className="flex gap-4 mb-4">
            {[
              { label: "Góc Trên", type: "image_top" },
              { label: "Góc Dưới", type: "image_bottom" },
              { label: "Góc Trái", type: "image_left" },
              { label: "Góc Phải", type: "image_right" },
              { label: "Chính Diện", type: "image_between" },
            ].map((button, index) => (
              <button
                key={index}
                onClick={() => captureImage(button.type)}
                className="bg-blue-500 text-white px-3 py-2 rounded hover:bg-blue-600 focus:outline-none"
              >
                {button.label}
              </button>
            ))}
          </div>
          <div className="flex flex-wrap justify-center mt-4 gap-5">
            {[
              { label: "Góc Trên", type: "image_top" },
              { label: "Góc Dưới", type: "image_bottom" },
              { label: "Góc Trái", type: "image_left" },
              { label: "Góc Phải", type: "image_right" },
              { label: "Chính Diện", type: "image_between" },
            ].map((slot, index) => (
              <div key={index} className="flex flex-col items-center">
                <p className="font-bold">{slot.label}</p>
                <img
                  src={formData[slot.type] || defaultAvatarUrl}
                  alt={slot.label}
                  className="w-32 h-18 border rounded mb-2 flex"
                />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default SignupUser;




