import React, { useState, useEffect } from "react";
import axios from "axios";
import md5 from "md5";
import Webcam from "react-webcam";
import { useNavigate } from "react-router-dom";

function SignupUser() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    id_nv: "",
    ma_qr: null,
    ten_nv: "",
    diachi_nv: "",
    email_nv: "",
    sdt_nv: "",
    gioitinh_nv: "1", // Default to 1 (Male)
    ngaysinh_nv: "",
    username: "",
    password: "",
    trangthai_taikhoan: "1",
    thoigian_tao: "",
    thoigian_xoa: null,
    image_top: "",
    image_bottom: "",
    image_left: "",
    image_right: "",
    image_between: "",
  });

  const [webcamOpen, setWebcamOpen] = useState(false);
  const [currentImageType, setCurrentImageType] = useState("");

  useEffect(() => {
    const currentDateTime = new Date().toISOString().slice(0, 16);
    setFormData((prevData) => ({ ...prevData, thoigian_tao: currentDateTime }));
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleGenderChange = (e) => {
    const { value } = e.target;
    setFormData({ ...formData, gioitinh_nv: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const hashedPassword = md5(formData.password);
    const submitData = { ...formData, password: hashedPassword };
    try {
      const response = await axios.post(
        "http://localhost:5000/register",
        submitData
      );
      alert(response.data.message);
      navigate("/login");
    } catch (error) {
      console.error("There was an error!", error);
    }
  };

  const openWebcam = (imageType) => {
    setCurrentImageType(imageType);
    setWebcamOpen(true);
  };

  const captureImage = async (imageSrc) => {
    try {
      const formData = new FormData();
      formData.append("image", dataURItoBlob(imageSrc));

      const response = await axios.post(
        "http://localhost:5000/verify-face",
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );

      if (response.data.success) {
        setFormData((prevData) => ({
          ...prevData,
          [currentImageType]: imageSrc,
        }));
        setWebcamOpen(false);
        alert("Đã nhận diện được gương mặt.")
      } else {
        alert("Không phát hiện gương mặt, vui lòng thử lại");
      }
    } catch (error) {
      console.error("Error verifying face:", error);
      alert("An error occurred while verifying the face.");
    }
  };

  const dataURItoBlob = (dataURI) => {
    let byteString;
    if (dataURI.split(",")[0].indexOf("base64") >= 0)
      byteString = atob(dataURI.split(",")[1]);
    else byteString = unescape(dataURI.split(",")[1]);

    const mimeString = dataURI.split(",")[0].split(":")[1].split(";")[0];
    const ia = new Uint8Array(byteString.length);
    for (let i = 0; i < byteString.length; i++) {
      ia[i] = byteString.charCodeAt(i);
    }

    return new Blob([ia], { type: mimeString });
  };

  return (
    <div className="flex justify-center m-5 p-5 rounded-xl bg-gray-100">
      <div className="flex flex-nowrap justify-center">
        <form
          onSubmit={handleSubmit}
          className="bg-white p-9 rounded shadow-md my-8 mx-4"
        >
          <h1 className="text-3xl uppercase font-bold mb-6 text-center">
            Đăng kí tài khoản
          </h1>
          {[
            {
              name: "id_nv",
              type: "text",
              placeholder: "ID_NV",
              label: "Mã NV",
            },
            {
              name: "ten_nv",
              type: "text",
              placeholder: "TEN_NV",
              label: "Họ & Tên",
            },
            {
              name: "diachi_nv",
              type: "text",
              placeholder: "DIACHI_NV",
              label: "Địa chỉ",
            },
            {
              name: "email_nv",
              type: "email",
              placeholder: "EMAIL_NV",
              label: "Email",
            },
            {
              name: "sdt_nv",
              type: "text",
              placeholder: "SDT_NV",
              label: "SĐT",
            },
            { name: "ngaysinh_nv", type: "date", label: "Ngày Sinh" },
            {
              name: "username",
              type: "text",
              placeholder: "Username",
              label: "Username",
            },
            {
              name: "password",
              type: "password",
              placeholder: "Password",
              label: "Password",
            },
          ].map((input) => (
            <div key={input.name} className="my-4 flex flex-col">
              <label className="mb-2 font-medium">
                {input.label}
                <input
                  type={input.type}
                  name={input.name}
                  placeholder={input.placeholder}
                  value={formData[input.name]}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-2 border rounded focus:outline-none focus:ring focus:border-blue-300"
                />
              </label>
            </div>
          ))}
          <div className="mb-4 flex gap-5">
            <label className="block mb-1 font-medium">Giới tính</label>
            <div className="flex items-center">
              <label className="mr-4">
                <input
                  type="radio"
                  name="gioitinh_nv"
                  value="1"
                  checked={formData.gioitinh_nv === "1"}
                  onChange={handleGenderChange}
                  className="mr-2"
                />
                Nam
              </label>
              <label>
                <input
                  type="radio"
                  name="gioitinh_nv"
                  value="0"
                  checked={formData.gioitinh_nv === "0"}
                  onChange={handleGenderChange}
                  className="mr-2"
                />
                Nữ
              </label>
            </div>
          </div>
          <input
            type="hidden"
            name="trangthai_taikhoan"
            value={formData.trangthai_taikhoan}
          />
          <input
            type="hidden"
            name="thoigian_tao"
            value={formData.thoigian_tao}
          />
          <input
            type="hidden"
            name="thoigian_xoa"
            value={formData.thoigian_xoa}
          />
          <button
            type="submit"
            className="w-full bg-green-500 text-white px-3 py-2 rounded hover:bg-green-600 focus:outline-none"
          >
            Register
          </button>
        </form>

        <div className="flex flex-wrap w-3/5 h-5 pl-5 pt-20">
          {[
            { name: "image_top", label: "Capture Top" },
            { name: "image_bottom", label: "Capture Bottom" },
            { name: "image_left", label: "Capture Left" },
            { name: "image_right", label: "Capture Right" },
            { name: "image_between", label: "Capture Between" },
          ].map((input) => (
            <div key={input.name} className="flex flex-col p-2 w-1/3">
              {formData[input.name] ? (
                <div className="relative">
                  <img
                    src={formData[input.name]}
                    alt={input.label}
                    className="w-full mb-2 rounded transform -scale-x-100"
                  />
                  <button
                    type="button"
                    onClick={() => openWebcam(input.name)}
                    className="w-full bg-pink-500 text-white px-3 py-2 rounded hover:bg-pink-600 focus:outline-none"
                  >
                    Retake {input.label}
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => openWebcam(input.name)}
                  className="w-full bg-blue-500 text-white px-3 py-2 rounded hover:bg-blue-600 focus:outline-none"
                >
                  {input.label}
                </button>
              )}
            </div>
          ))}
        </div>
      </div>

      {webcamOpen && (
        <div className="fixed inset-0 flex justify-center items-center bg-black bg-opacity-50">
          <div className="bg-white p-4 rounded-lg shadow-lg">
            <Webcam
              audio={false}
              screenshotFormat="image/jpeg"
              width={480}
              height={360}
              className="rounded transform -scale-x-100"
            >
              {({ getScreenshot }) => (
                <div className="flex justify-center pt-5 gap-3">
                  <button
                    onClick={() => {
                      const imageSrc = getScreenshot();
                      captureImage(imageSrc);
                    }}
                    className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 focus:outline-none"
                  >
                    Capture
                  </button>
                  <button
                    onClick={() => setWebcamOpen(false)}
                    className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 focus:outline-none"
                  >
                    Cancel
                  </button>
                </div>
              )}
            </Webcam>
          </div>
        </div>
      )}
    </div>
  );
}

// const InputField = ({ name, type, placeholder, label, value, onChange }) => (
//   <div className="my-4 flex flex-col">
//     <label className="mb-2 font-medium">
//       {label}
//       <input
//         type={type}
//         name={name}
//         placeholder={placeholder}
//         value={value}
//         onChange={onChange}
//         required
//         className="w-full px-4 py-2 border rounded focus:outline-none focus:ring focus:border-blue-300"
//       />
//     </label>
//   </div>
// );

// const GenderRadio = ({ value, onChange }) => (
//   <div className="mb-4 flex gap-5">
//     <label className="block mb-1 font-medium">Giới tính</label>
//     <div className="flex items-center">
//       <label className="mr-4">
//         <input
//           type="radio"
//           name="gioitinh_nv"
//           value="1"
//           checked={value === "1"}
//           onChange={onChange}
//           className="mr-2"
//         />
//         Nam
//       </label>
//       <label>
//         <input
//           type="radio"
//           name="gioitinh_nv"
//           value="0"
//           checked={value === "0"}
//           onChange={onChange}
//           className="mr-2"
//         />
//         Nữ
//       </label>
//     </div>
//   </div>
// );

// const ImageCaptureButton = ({ name, label, image, onClick }) => (
//   <div className="flex flex-col p-2 w-1/3">
//     {image ? (
//       <div className="relative">
//         <img
//           src={image}
//           alt={label}
//           className="w-full mb-2 rounded transform -scale-x-100"
//         />
//         <button
//           type="button"
//           onClick={() => onClick(name)}
//           className="w-full bg-pink-500 text-white px-3 py-2 rounded hover:bg-pink-600 focus:outline-none"
//         >
//           Retake {label}
//         </button>
//       </div>
//     ) : (
//       <button
//         type="button"
//         onClick={() => onClick(name)}
//         className="w-full bg-blue-500 text-white px-3 py-2 rounded hover:bg-blue-600 focus:outline-none"
//       >
//         {label}
//       </button>
//     )}
//   </div>
// );

export default SignupUser;
