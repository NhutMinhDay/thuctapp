const path = require('path');

module.exports = function override(config, env) {
  // Thêm fallback cho module `fs`
  config.resolve.fallback = {
    ...config.resolve.fallback,
    fs: false,
  };

  return config;
};
