    # VECTO.clear()
    # VECTO_QR.clear()
    # print("RỖNG :",VECTO, VECTO_QR)