// import React, { useState } from "react";
// import axios from "axios";
// import { ImagetoBase64 } from "../../utility/ImagetoBase64";

// const FormImage = ({ entry }) => {
//   const [formData, setFormData] = useState({
//     ID_NV: entry.ID_NV,
//     IMAGE_TOP: entry.IMAGE_TOP,
//     IMAGE_BOTTOM: entry.IMAGE_BOTTOM,
//     IMAGE_LEFT: entry.IMAGE_LEFT,
//     IMAGE_RIGHT: entry.IMAGE_RIGHT,
//     IMAGE_BETWEEN: entry.IMAGE_BETWEEN,
//     new_IDNV: "",
//     new_IMAGE_TOP: "",
//     new_IMAGE_BOTTOM: "",
//     new_IMAGE_LEFT: "",
//     new_IMAGE_RIGHT: "",
//     new_IMAGE_BETWEEN: "",
//   });

//   // console.log(entry.ID_IMAGE);

//   const [loading, setLoading] = useState(false);
//   // const [error, setError] = useState(null);
//   // const [success, setSuccess] = useState(false);
//   // const [showNewImage, setShowNewImage] = useState(false); // Toggle state

//   const handleImageChange = async (event) => {
//     const file = event.target.files[0];
//     if (file) {
//       try {
//         const base64Image = await ImagetoBase64(file);
//         setFormData({
//           ...formData,
//           // new_IDNV: "",
//           new_IMAGE_TOP: base64Image,
//           new_IMAGE_BOTTOM: base64Image,
//           new_IMAGE_LEFT: base64Image,
//           new_IMAGE_RIGHT: base64Image,
//           new_IMAGE_BETWEEN: base64Image,
//         });
//       } catch (error) {
//         console.error("Error converting image to base64:", error);
//       }
//     }
//   };

//   console.log(formData);

//   const handleChange = (event) => {
//     const { name, value } = event.target;
//     setFormData({
//       ...formData,
//       [name]: value,
//     });
//   };

//   const handleSubmit = async (event) => {
//     event.preventDefault();
//     setLoading(true);
//     // setError(null);

//     const updatedData = { ...formData };

//     updatedData.ID_NV = formData.new_IDNV;
//     delete updatedData.new_IDNV;

//     updatedData.IMAGE_TOP = formData.new_IMAGE_TOP;
//     delete updatedData.new_IMAGE_TOP;

//     updatedData.IMAGE_BOTTOM = formData.new_IMAGE_BOTTOM;
//     delete updatedData.new_IMAGE_BOTTOM;

//     updatedData.IMAGE_LEFT = formData.new_IMAGE_LEFT;
//     delete updatedData.new_IMAGE_RIGHT;

//     updatedData.IMAGE_RIGHT = formData.new_IMAGE_RIGHT;
//     delete updatedData.new_IMAGE_RIGHT;

//     updatedData.IMAGE_BETWEEN = formData.new_IMAGE_BETWEEN;
//     delete updatedData.new_IMAGE_BETWEEN;

    

//     await axios.put(`/api/image_base64_nv/${entry.ID_IMAGE}`, updatedData);
//     console.log("Update QR successful");
//     console.log("updata",updatedData)
//     // setSuccess(true);
//     console.log(updatedData);
//     // window.location.reload(); // Reload trang sau khi thành công
//   };

//   return (
//     <div className="mt-8">
//       <h2 className="text-lg font-semibold mb-4">Cập Nhật Ảnh</h2>
//       <form onSubmit={handleSubmit} className="max-w-sm">
//         <label className="block mb-2">
//           Mã Nhân Viên:
//           <input
//             type="text"
//             name="new_IDNV"
//             onChange={handleChange}
//             className="mt-2"
//           />
//         </label>
//         <br />

//         <label className="block mb-2">
//           New Image Top:
//           <input
//             type="file"
//             accept="image/*"
//             name="new_IMAGE_TOP"
//             onChange={handleImageChange}
//             className="mt-2"
//           />
//         </label>
//         <br />
//         <label className="block mb-2">
//           New Image BOTTOM:
//           <input
//             type="file"
//             accept="image/*"
//             name="new_IMAGE_BOTTOM"
//             onChange={handleImageChange}
//             className="mt-2"
//           />
//         </label>
//         <br />
//         <label className="block mb-2">
//           New Image LEFT:
//           <input
//             type="file"
//             accept="image/*"
//             name="new_IMAGE_LEFT"
//             onChange={handleImageChange}
//             className="mt-2"
//           />
//         </label>
//         <br />
//         <label className="block mb-2">
//           New Image RIGHT:
//           <input
//             type="file"
//             accept="image/*"
//             name="new_IMAGE_RIGHT"
//             onChange={handleImageChange}
//             className="mt-2"
//           />
//         </label>
//         <br />
//         <label className="block mb-2">
//           New Image BETWEEN:
//           <input
//             type="file"
//             accept="image/*"
//             name="new_IMAGE_BETWEEN"
//             onChange={handleImageChange}
//             className="mt-2"
//           />
//         </label>
//         <br />

//         <button
//           type="submit"
//           disabled={loading}
//           className="bg-blue-500 text-white py-2 px-4 rounded"
//         >
//           {loading ? "Đang cập nhật..." : "Update"}
//         </button>
//       </form>
//     </div>
//   );
// };

// export default FormImage;









// //  2:56 6/12/2024
// import React, { useState } from "react";
// import axios from "axios";
// import { ImagetoBase64 } from "../../utility/ImagetoBase64";

// const FormImage = ({ entry }) => {
//   const [formData, setFormData] = useState({
//     ID_NV: entry.ID_NV,
//     IMAGE_TOP: entry.IMAGE_TOP,
//     IMAGE_BOTTOM: entry.IMAGE_BOTTOM,
//     IMAGE_LEFT: entry.IMAGE_LEFT,
//     IMAGE_RIGHT: entry.IMAGE_RIGHT,
//     IMAGE_BETWEEN: entry.IMAGE_BETWEEN,
//     new_IDNV: "",
//     new_IMAGE_TOP: "",
//     new_IMAGE_BOTTOM: "",
//     new_IMAGE_LEFT: "",
//     new_IMAGE_RIGHT: "",
//     new_IMAGE_BETWEEN: "",
//   });

//   const [loading, setLoading] = useState(false);

//   const handleImageChange = async (event) => {
//     const { name, files } = event.target;
//     const file = files[0];
//     if (file) {
//       try {
//         const base64Image = await ImagetoBase64(file);
//         setFormData({
//           ...formData,
//           [name]: base64Image,
//         });
//       } catch (error) {
//         console.error("Error converting image to base64:", error);
//       }
//     }
//   };

//   const handleChange = (event) => {
//     const { name, value } = event.target;
//     setFormData({
//       ...formData,
//       [name]: value,
//     });
//   };

//   const handleSubmit = async (event) => {
//     event.preventDefault();
//     setLoading(true);

//     const updatedData = {
//       ID_NV: formData.new_IDNV || formData.ID_NV,
//       IMAGE_TOP: formData.new_IMAGE_TOP || formData.IMAGE_TOP,
//       IMAGE_BOTTOM: formData.new_IMAGE_BOTTOM || formData.IMAGE_BOTTOM,
//       IMAGE_LEFT: formData.new_IMAGE_LEFT || formData.IMAGE_LEFT,
//       IMAGE_RIGHT: formData.new_IMAGE_RIGHT || formData.IMAGE_RIGHT,
//       IMAGE_BETWEEN: formData.new_IMAGE_BETWEEN || formData.IMAGE_BETWEEN,
//     };

//     try {
//       await axios.put(`http://localhost:5000/api/image_base64_nv/${entry.ID_IMAGE}`, updatedData);
//       console.log("Update QR successful");
//       console.log("updatedData", updatedData);
//       // Reload page or handle success state
//     } catch (error) {
//       console.error("Error updating image data:", error);
//     } finally {
//       setLoading(false);
//     }
//   };


  




//   return (
//     <center>
//       <div className="mt-8">
//       <h2 className="text-lg font-semibold mb-4">Cập Nhật Ảnh</h2>
//       <form onSubmit={handleSubmit} className="max-w-sm">
//         <label className="block mb-2">
//           Mã Nhân Viên:
//           <input
//             type="text"
//             name="new_IDNV"
//             value={formData.new_IDNV}
//             onChange={handleChange}
//             className="mt-2"
//           />
//         </label>
//         <br />
//         <label className="block mb-2">
//           New Image Top:
//           <input
//             type="file"
//             accept="image/*"
//             name="new_IMAGE_TOP"
//             onChange={handleImageChange}
//             className="mt-2"
//           />
//         </label>
//         <br />
//         <label className="block mb-2">
//           New Image Bottom:
//           <input
//             type="file"
//             accept="image/*"
//             name="new_IMAGE_BOTTOM"
//             onChange={handleImageChange}
//             className="mt-2"
//           />
//         </label>
//         <br />
//         <label className="block mb-2">
//           New Image Left:
//           <input
//             type="file"
//             accept="image/*"
//             name="new_IMAGE_LEFT"
//             onChange={handleImageChange}
//             className="mt-2"
//           />
//         </label>
//         <br />
//         <label className="block mb-2">
//           New Image Right:
//           <input
//             type="file"
//             accept="image/*"
//             name="new_IMAGE_RIGHT"
//             onChange={handleImageChange}
//             className="mt-2"
//           />
//         </label>
//         <br />
//         <label className="block mb-2">
//           New Image Between:
//           <input
//             type="file"
//             accept="image/*"
//             name="new_IMAGE_BETWEEN"
//             onChange={handleImageChange}
//             className="mt-2"
//           />
//         </label>
//         <br />
//         <button
//           type="submit"
//           disabled={loading}
//           className="bg-blue-500 text-white py-2 px-4 rounded"
//         >
//           {loading ? "Đang cập nhật..." : "Update"}
//         </button>
//       </form>
//     </div>
//     </center>
    
//   );
// };

// export default FormImage;





import React, { useState } from "react";
import axios from "axios";
import { ImagetoBase64 } from "../../utility/ImagetoBase64";

const FormImage = ({ entry }) => {
  const [formData, setFormData] = useState({
    ID_NV: entry.ID_NV,
    IMAGE_TOP: entry.IMAGE_TOP,
    IMAGE_BOTTOM: entry.IMAGE_BOTTOM,
    IMAGE_LEFT: entry.IMAGE_LEFT,
    IMAGE_RIGHT: entry.IMAGE_RIGHT,
    IMAGE_BETWEEN: entry.IMAGE_BETWEEN,
    new_IDNV: "",
    new_IMAGE_TOP: "",
    new_IMAGE_BOTTOM: "",
    new_IMAGE_LEFT: "",
    new_IMAGE_RIGHT: "",
    new_IMAGE_BETWEEN: "",
  });

  const [loading, setLoading] = useState(false);

  const handleImageChange = async (event) => {
    const { name, files } = event.target;
    const file = files[0];
    if (file) {
      try {
        const base64Image = await ImagetoBase64(file);
        setFormData({
          ...formData,
          [name]: base64Image,
        });
      } catch (error) {
        console.error("Error converting image to base64:", error);
      }
    }
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);
  
    const updatedData = {
      ID_NV: formData.new_IDNV || formData.ID_NV,
      IMAGE_TOP: formData.new_IMAGE_TOP || formData.IMAGE_TOP,
      IMAGE_BOTTOM: formData.new_IMAGE_BOTTOM || formData.IMAGE_BOTTOM,
      IMAGE_LEFT: formData.new_IMAGE_LEFT || formData.IMAGE_LEFT,
      IMAGE_RIGHT: formData.new_IMAGE_RIGHT || formData.IMAGE_RIGHT,
      IMAGE_BETWEEN: formData.new_IMAGE_BETWEEN || formData.IMAGE_BETWEEN,
    };
  
    try {
      await axios.put(`http://localhost:5000/api/image_base64_nv/${entry.ID_IMAGE}`, updatedData);
      console.log("Update QR successful");
      console.log("updatedData", updatedData);
  
      // Check if any image fields were updated
      const isImageChanged = Object.keys(updatedData).some(key =>
        key.startsWith("new_IMAGE_") && updatedData[key] !== formData[key]
      );
  
      // If image changed, update vector
      if (isImageChanged) {
        await updateVectorIfImageChanged(entry.ID_NV, updatedData);
      }
  
      // Reload page or handle success state
    } catch (error) {
      console.error("Error updating image data:", error);
    } finally {
      setLoading(false);
    }
  };
  


  const updateVectorIfImageChanged = async (entryID, updatedData) => {
    try {
      const response = await axios.post(`http://localhost:5000/api/update_vector/${entryID}`, updatedData);
      console.log("Update vector successful");
      console.log("Updated vector data:", response.data);
      // Handle success (if needed)
    } catch (error) {
      console.error("Error updating vector:", error);
    }
  };
  


  return (
    <center>
      <div className="mt-8">
      <h2 className="text-lg font-semibold mb-4">Cập Nhật Ảnh</h2>
      <form onSubmit={handleSubmit} className="max-w-sm">
        <label className="block mb-2">
          Mã Nhân Viên:
          <input
            type="text"
            name="new_IDNV"
            value={formData.new_IDNV}
            onChange={handleChange}
            className="mt-2"
          />
        </label>
        <br />
        <label className="block mb-2">
          New Image Top:
          <input
            type="file"
            accept="image/*"
            name="new_IMAGE_TOP"
            onChange={handleImageChange}
            className="mt-2"
          />
        </label>
        <br />
        <label className="block mb-2">
          New Image Bottom:
          <input
            type="file"
            accept="image/*"
            name="new_IMAGE_BOTTOM"
            onChange={handleImageChange}
            className="mt-2"
          />
        </label>
        <br />
        <label className="block mb-2">
          New Image Left:
          <input
            type="file"
            accept="image/*"
            name="new_IMAGE_LEFT"
            onChange={handleImageChange}
            className="mt-2"
          />
        </label>
        <br />
        <label className="block mb-2">
          New Image Right:
          <input
            type="file"
            accept="image/*"
            name="new_IMAGE_RIGHT"
            onChange={handleImageChange}
            className="mt-2"
          />
        </label>
        <br />
        <label className="block mb-2">
          New Image Between:
          <input
            type="file"
            accept="image/*"
            name="new_IMAGE_BETWEEN"
            onChange={handleImageChange}
            className="mt-2"
          />
        </label>
        <br />
        <button
          type="submit"
          disabled={loading}
          className="bg-blue-500 text-white py-2 px-4 rounded"
        >
          {loading ? "Đang cập nhật..." : "Update"}
        </button>
      </form>
    </div>
    </center>
    
  );
};

export default FormImage;
