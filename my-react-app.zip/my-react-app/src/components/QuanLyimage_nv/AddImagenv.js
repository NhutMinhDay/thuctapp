import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { ImagetoBase64 } from "../../utility/ImagetoBase64";

const AddImagenv = () => {
  const [form, setForm] = useState({
    ID_NV: "",
    IMAGE_TOP: null,
    IMAGE_BOTTOM: null,
    IMAGE_LEFT: null,
    IMAGE_RIGHT: null,
    IMAGE_BETWEEN: null,
  });
  const [nhanvienList, setNhanvienList] = useState([]);
  const [error, setError] = useState("");
  const [imagePreviews, setImagePreviews] = useState({
    IMAGE_TOP: null,
    IMAGE_BOTTOM: null,
    IMAGE_LEFT: null,
    IMAGE_RIGHT: null,
    IMAGE_BETWEEN: null,
  });
  const navigate = useNavigate();

  useEffect(() => {
    axios
      .get("/api/nhanvien")
      .then((response) => {
        const data = response.data;
        const formattedData = data.map((item) => ({
          ID_NV: item[0],
          TEN_NV: item[1],
        }));
        setNhanvienList(formattedData);
      })
      .catch((error) => {
        setError("Đã xảy ra lỗi khi tải danh sách nhân viên.");
        console.error(error);
      });
  }, []);

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    if (files) {
      setForm((prevState) => ({
        ...prevState,
        [name]: files[0],
      }));

      // Hiển thị trước ảnh khi được chọn
      const reader = new FileReader();
      reader.onload = (e) => {
        setImagePreviews((prevState) => ({
          ...prevState,
          [name]: e.target.result,
        }));
      };
      reader.readAsDataURL(files[0]);
    } else {
      setForm((prevState) => ({
        ...prevState,
        [name]: value,
      }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const formData = { ID_NV: form.ID_NV };
      if (form.IMAGE_TOP) {
        const base64Top = await ImagetoBase64(form.IMAGE_TOP);
        formData.IMAGE_TOP = base64Top;
      }
      if (form.IMAGE_BOTTOM) {
        const base64Bottom = await ImagetoBase64(form.IMAGE_BOTTOM);
        formData.IMAGE_BOTTOM = base64Bottom;
      }
      if (form.IMAGE_LEFT) {
        const base64Left = await ImagetoBase64(form.IMAGE_LEFT);
        formData.IMAGE_LEFT = base64Left;
      }
      if (form.IMAGE_RIGHT) {
        const base64Right = await ImagetoBase64(form.IMAGE_RIGHT);
        formData.IMAGE_RIGHT = base64Right;
      }
      if (form.IMAGE_BETWEEN) {
        const base64Between = await ImagetoBase64(form.IMAGE_BETWEEN);
        formData.IMAGE_BETWEEN = base64Between;
      }
      await axios.post("/api/image_base64_nv", formData);
      console.log("Thêm ảnh Nhân Viên thành công!!!");
      navigate("/listimage");
    } catch (err) {
      setError("Đã xảy ra lỗi khi tải ảnh lên.");
      console.error(err);
    }
  };

  return (
    <div className="flex justify-center">
      <div className="w-full sm:w-1/2 lg:w-2/3">
        <h2 className="text-center text-xl font-bold mb-4">
          Thêm Ảnh Base64 Nhân Viên
        </h2>
        <form onSubmit={handleSubmit} className="border border-gray-400 p-2 m-2 rounded-md">
          <div className="mb-4">
            <label className="block mb-1">ID NV:</label>
            <select
              name="ID_NV"
              value={form.ID_NV}
              onChange={handleChange}
              required
              className="block w-full py-1 px-2 border border-gray-300 rounded-md focus:outline-none focus:border-blue-400"
            >
              <option value="">Chọn nhân viên</option>
              {nhanvienList.map((nhanvien) => (
                <option key={nhanvien.ID_NV} value={nhanvien.ID_NV}>
                  {nhanvien.TEN_NV}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-3 gap-4">
            {[
              { name: "IMAGE_TOP", label: "Ảnh Top" },
              { name: "IMAGE_BOTTOM", label: "Ảnh Bottom" },
              { name: "IMAGE_LEFT", label: "Ảnh Left" },
              { name: "IMAGE_RIGHT", label: "Ảnh Right" },
              { name: "IMAGE_BETWEEN", label: "Ảnh Between" },
            ].map((field, index) => (
              <div key={index} className="flex flex-col">
                <label className="block mb-1">{field.label}:</label>
                <input
                  type="file"
                  name={field.name}
                  accept="image/*"
                  onChange={(e) => handleChange(e, field.name)}
                  className="w-full border border-gray-300 rounded-md py-1 px-3 focus:outline-none focus:border-blue-400"
                />
                {/* Hiển thị trước ảnh */}
                {imagePreviews[field.name] && (
                  <img
                    src={imagePreviews[field.name]}
                    alt={field.name}
                    className="mt-2 w-20 h-20"
                  />
                )}
              </div>
            ))}
          </div>
          <button
            type="submit"
            className="bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded-md"
          >
            Thêm
          </button>
        </form>
        {error && <p className="text-red-500 mt-2">{error}</p>}
      </div>
    </div>
  );
};

export default AddImagenv;
