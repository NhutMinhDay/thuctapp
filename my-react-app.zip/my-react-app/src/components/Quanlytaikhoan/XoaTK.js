import React, { useState } from "react";
import axios from "axios";

const SearchUser = () => {
  const [searchId, setSearchId] = useState("");
  const [searchResult, setSearchResult] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleSearchChange = (e) => {
    setSearchId(e.target.value);
  };

  const handleSearch = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await axios.get(`http://localhost:5000/edit/${searchId}`);
      setSearchResult(response.data);
    } catch (error) {
      console.error("Error fetching user info:", error);
      setError("Không tìm thấy thông tin nhân viên");
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateStatus = async () => {
    if (!window.confirm("Bạn có chắc chắn muốn cập nhật trạng thái nhân viên này?")) {
      return;
    }

    setLoading(true);
    try {
      const response = await axios.put(`http://localhost:5000/edit/updatetk/${searchResult.id_nv}`, {
        trangthai: 0 // Gửi trạng thái mới để cập nhật
      });
      alert(response.data.message);

      // Cập nhật lại thông tin nhân viên trong searchResult
      setSearchResult({ ...searchResult, trangthai: 0 }); // Cập nhật trạng thái hiển thị ngay lập tức
    } catch (error) {
      console.error("Error updating user status:", error);
      alert("Lỗi. Tài Khoản đã bị xóa hoặc không tồn tại:");
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateTK = async () => {
    if (!window.confirm("Bạn có chắc chắn muốn khôi phục trạng thái nhân viên này?")) {
      return;
    }
  
    setLoading(true);
    setError(null);  // Reset error before making the API call
    try {
      const response = await axios.put(`http://localhost:5000/edit/restore/${searchResult.id_nv}`);
      alert(response.data.message);
  
      // Cập nhật lại thông tin nhân viên trong searchResult
      setSearchResult({ ...searchResult, trangthai: 1 }); // Cập nhật trạng thái hiển thị ngay lập tức
    } catch (error) {
      console.error("Error restoring user status:", error);
      alert("Lỗi. Tài khoản không tồn tại hoặc đã khôi phục:");
    } finally {
      setLoading(false);
    }
  };
  

  return (
    <div style={{ display: "flex", justifyContent: "center" }}>
      <div style={{ width: "50%" }}>
        <h2 style={{ textAlign: "center" }}>Quản lý nhân viên</h2>

        <table className="border-collapse border border-gray-400 w-full mb-4">
          <thead>
            <tr>
              <th className="border border-gray-300 px-4 py-2" colSpan="2">
                Xóa tài khoản nhân viên
              </th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="border border-gray-300 px-4 py-2">
                Nhập ID:
                <input
                  type="text"
                  value={searchId}
                  onChange={handleSearchChange}
                  disabled={loading}
                  className="ml-2 p-1 border border-gray-300"
                />
              </td>
              <td className="border border-gray-300 px-4 py-2">
                <button
                  onClick={handleSearch}
                  className={`bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 focus:outline-none ${loading && 'opacity-50 cursor-not-allowed'}`}
                  disabled={loading}
                >
                  {loading ? "Đang xóa..." : "Xóa"}
                </button>
              </td>
            </tr>
            {error && (
              <tr>
                <td colSpan="2" className="text-red-500 text-center py-2" style={{ backgroundColor: "#FED7D7" }}>
                  {error}
                </td>
              </tr>
            )}
            {searchResult && (
              <tr>
                <td className="border border-gray-300 px-4 py-2" colSpan="2">
                  <h4>Thông tin nhân viên:</h4>
                  <p>Tên: {searchResult.name}</p>
                  <p>Địa chỉ: {searchResult.address}</p>
                  <p>Email: {searchResult.email}</p>
                  <p>Số điện thoại: {searchResult.phone}</p>
                  <p>ID Nhân Viên: {searchResult.id_nv}</p>
                  <p>Giới Tính: {searchResult.gender}</p>
                  <p>Ngày Sinh Nhân Viên: {searchResult.dob}</p>
                  <p>Trạng thái: {searchResult.trangthai === 1 ? "Hoạt Động" : "Không Hoạt Động"}</p>
                </td>
              </tr>
            )}
          </tbody>
        </table>

        {searchResult && (
          <table className="border-collapse border border-gray-400 w-full mb-4">
            <thead>
              <tr>
                <th className="border border-gray-300 px-4 py-2" colSpan="2">
                  Cập nhật trạng thái
                </th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="border border-gray-300 px-4 py-2" colSpan="2">
                  <div style={{ display: 'flex', gap: '10px' }}>
                    <button
                      onClick={handleUpdateStatus}
                      className={`bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 focus:outline-none ${loading && 'opacity-50 cursor-not-allowed'}`}
                      disabled={loading}
                    >
                      {loading ? "Đang Xóa..." : "Xóa"}
                    </button>
                    <button
                      onClick={handleUpdateTK}
                      className={`bg-green-500 text-white px-4 py-2 rounded hover:bg-yellow-600 focus:outline-none ${loading && 'opacity-50 cursor-not-allowed'}`}
                      disabled={loading}
                    >
                      {loading ? "Đang cập nhật" : "Khôi phục tài khoản"}
                    </button>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default SearchUser;
