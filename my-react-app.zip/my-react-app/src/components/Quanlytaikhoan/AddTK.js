
import React, { useState, useEffect } from "react";
import axios from "axios";

const SearchUser = () => {
  const [searchId, setSearchId] = useState("");
  const [searchResult, setSearchResult] = useState(null);
  const [updateData, setUpdateData] = useState({
    ma_qr: "",
    ten_nv: "",
    diachi_nv: "",
    email_nv: "",
    sdt_nv: "",
    gioitinh_nv: "",
    ngaysinh_nv: "",
  });
  const [newData, setNewData] = useState({
    id_nv: "",
    ma_qr: "",
    ten_nv: "",
    diachi_nv: "",
    email_nv: "",
    sdt_nv: "",
    gioitinh_nv: "",
    ngaysinh_nv: "",
  });
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setUpdateData({
      ma_qr: "",
      ten_nv: "",
      diachi_nv: "",
      email_nv: "",
      sdt_nv: "",
      gioitinh_nv: "",
      ngaysinh_nv: "",
    });
    setSearchResult(null);
  }, [searchId]);

  const handleSearchChange = (e) => {
    setSearchId(e.target.value);
  };

  const handleSearch = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await axios.get(`http://localhost:5000/edit/${searchId}`);
      setSearchResult(response.data);
      setUpdateData({
        ma_qr: response.data.ma_qr,
        ten_nv: response.data.name,
        diachi_nv: response.data.address,
        email_nv: response.data.email,
        sdt_nv: response.data.phone,
        gioitinh_nv: response.data.gender,
        ngaysinh_nv: response.data.dob,
      });
    } catch (error) {
      console.error("Error fetching user info:", error);
      setError("Không tìm thấy thông tin nhân viên");
    } finally {
      setLoading(false);
    }
  };



  const handleUpdateChange = (e) => {
    const { name, value } = e.target;
    setUpdateData({
      ...updateData,
      [name]: value,
    });
  };

  const handleUpdate = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await axios.put(`http://localhost:5000/edit/update/${searchId}`, updateData);
      setSearchResult(response.data);
      alert("Cập nhật nhân viên thành công");
    } catch (error) {
      console.error("Error updating user info:", error);
      setError("Lỗi khi cập nhật nhân viên");
    } finally {
      setLoading(false);
    }
  };









  return (
    <center>
      <div>
        <h2>Quản lý nhân viên</h2>





        {/* Tìm kiếm nhân viên */}
        <table className="border-collapse border border-gray-400 w-1/2 mb-4">
          <thead>
            <tr>
              <th className="border border-gray-300 px-4 py-2" colSpan="2">Tài Khoản Cập Nhật</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="border border-gray-300 px-4 py-2">
                Nhập ID:
                <input
                  type="text"
                  value={searchId}
                  onChange={handleSearchChange}
                  disabled={loading}
                  className="ml-2 p-1 border border-gray-300"
                />
              </td>
              <td className="border border-gray-300 px-4 py-2">
                <button
                  onClick={handleSearch}
                  className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 focus:outline-none"
                  disabled={loading}
                >
                  {loading ? "Đang cập nhật..." : "Cập Nhật Tài Khoản"}
                </button>
              </td>
            </tr>
            {error && (
              <tr>
                <td colSpan="2" className="text-red-500 text-center">{error}</td>
              </tr>
            )}
            {searchResult && (
              <tr>
                <td className="border border-gray-300 px-4 py-2" colSpan="2">
                  <h4>Thông tin nhân viên:</h4>
                  <p>Tên: {searchResult.name}</p>
                  <p>Địa chỉ: {searchResult.address}</p>
                  <p>Email: {searchResult.email}</p>
                  <p>Số điện thoại: {searchResult.phone}</p>
                  <p>ID Nhân Viên: {searchResult.id_nv}</p>
                  <p>Giới Tính: {searchResult.gender}</p>
                  <p>Ngày Sinh Nhân Viên: {searchResult.dob}</p>
                 {/* <p>Trạng thái: {searchResult.trangthai === 1 ? "Hoạt Động" : "Không Còn Hoạt Động"}</p> */}
                </td>
              </tr>
            )}
          </tbody>
        </table>

        {/* Cập nhật nhân viên */}
        {searchResult && (
          <table className="border-collapse border border-gray-400 w-1/2 mb-4">
            <thead>
              <tr>
                <th className="border border-gray-300 px-4 py-2" colSpan="2">Cập nhật thông tin nhân viên</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="border border-gray-300 px-4 py-2">
                  Mã QR:
                  <input
                    type="text"
                    name="ma_qr"
                    value={updateData.ma_qr}
                    onChange={handleUpdateChange}
                    disabled={loading}
                    className="ml-2 p-1 border border-gray-300"
                  />
                </td>
                <td className="border border-gray-300 px-4 py-2">
                  Tên nhân viên:
                  <input
                    type="text"
                    name="ten_nv"
                    value={updateData.ten_nv}
                    onChange={handleUpdateChange}
                    disabled={loading}
                    className="ml-2 p-1 border border-gray-300"
                  />
                </td>
              </tr>
              <tr>
                <td className="border border-gray-300 px-4 py-2">
                  Địa chỉ:
                  <input
                    type="text"
                    name="diachi_nv"
                    value={updateData.diachi_nv}
                    onChange={handleUpdateChange}
                    disabled={loading}
                    className="ml-2 p-1 border border-gray-300"
                  />
                </td>
                <td className="border border-gray-300 px-4 py-2">
                  Email:
                  <input
                    type="text"
                    name="email_nv"
                    value={updateData.email_nv}
                    onChange={handleUpdateChange}
                    disabled={loading}
                    className="ml-2 p-1 border border-gray-300"
                  />
                </td>
              </tr>
              <tr>
                <td className="border border-gray-300 px-4 py-2">
                  Số điện thoại:
                  <input
                    type="text"
                    name="sdt_nv"
                    value={updateData.sdt_nv}
                    onChange={handleUpdateChange}
                    disabled={loading}
                    className="ml-2
p-1 border border-gray-300"
                  />
                </td>
                <td className="border border-gray-300 px-4 py-2">
                  Giới tính:
                  <input
                    type="text"
                    name="gioitinh_nv"
                    value={updateData.gioitinh_nv}
                    onChange={handleUpdateChange}
                    disabled={loading}
                    className="ml-2 p-1 border border-gray-300"
                  />
                </td>
              </tr>
              <tr>
                <td className="border border-gray-300 px-4 py-2">
                  Ngày sinh:
                  <input
                    type="text"
                    name="ngaysinh_nv"
                    value={updateData.ngaysinh_nv}
                    onChange={handleUpdateChange}
                    disabled={loading}
                    className="ml-2 p-1 border border-gray-300"
                  />
                </td>
                <td className="border border-gray-300 px-4 py-2">
                  <button
                    onClick={handleUpdate}
                    className="bg-yellow-500 text-black px-4 py-2 rounded hover:bg-yellow-600 focus:outline-none"
                    disabled={loading}
                  >
                    Xác Nhận Cập Nhật
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        )}

      </div>
    </center>
  );
};


export default SearchUser;







