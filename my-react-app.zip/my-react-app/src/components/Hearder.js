// import React from "react";
// // import { FaSearch } from "react-icons/fa";
// import { Link } from "react-router-dom";

// const Header = () => {
//   return (
//     <header className="fixed bg-gray-200 shadow-md h-full w-[10%] flex float-right flex-col">
//       <div className="mx-auto p-3">
//         <Link to={"/"}>
//           <h1 className="font-bold text-sm sm:text-xl flex flex-wrap">
//             <span className="text-slate-500">Face</span>
//             <span className="text-slate-700">NMH</span>
//           </h1>
//         </Link>
//         {/*<form className="bg-slate-100 p-3 rounded-lg flex items-center">
//           <input
//             type="text"
//             placeholder="Search..."
//             className="bg-transparent focus:outline-none w-24 sm:w-64"
//           />
//           <FaSearch className="text-slate-600" />
//         </form>*/}

//         <ul className="flex flex-col gap-4">
//           <Link to={"/"}>
//             <li className="hidden sm:inline text-slate-700 hover:underline">
//               Home
//             </li>
//           </Link>

//           <Link to={"/list"}>
//             <li className="hidden sm:inline text-slate-700 hover:underline">
//               Điểm Danh
//             </li>
//           </Link>
//           <Link to={"/listqr"} className="text-slate-700 hover:underline">
//             <li>Mã QR</li>
//           </Link>
//           <Link to={"/sign-in"}>
//             <li className="sm:inline text-slate-700 hover:underline">
//               Sign in
//             </li>
//           </Link>
//         </ul>
//       </div>
//     </header>
//   );
// };

// export default Header;

import React from "react";
import { Link } from "react-router-dom";

const Header = () => {
  return (
    <header className="fixed left-0 top-0 bg-gray-200 shadow-md h-full flex flex-col sm:w-[20%] md:w-[15%] lg:w-[10%]">
      <div className="mx-auto p-3">
        <Link to={"/"}>
          <h1 className="font-bold text-sm sm:text-xl flex flex-wrap">
            <span className="text-slate-500">Face</span>
            <span className="text-slate-700">NMH</span>
          </h1>
        </Link>

        <ul className="flex flex-col gap-4 mt-4 ">
        
          <Link to={"/"} className="text-slate-700 hover:underline">
            <li>Home</li>
          </Link>
          <Link to={"/list"} className="text-slate-700 hover:underline">
            <li>Điểm Danh</li>
          </Link>
          <Link to={"/listqr"} className="text-slate-700 hover:underline">
            <li>Mã QR</li>
          </Link>
          <Link to={"/listimage"} className="text-slate-700 hover:underline">
            <li>Ảnh Nhân Viên</li>
          </Link>
          <Link to={"/log"} className="text-slate-700 hover:underline">
            <li>Sign in</li>
          </Link>
          <Link to={"/edit"} className="text-slate-700 hover:underline">
            <li>Cập Nhật</li>
          </Link>
          <Link to={"/delete"} className="text-slate-700 hover:underline">
            <li>Xóa</li>
          </Link>
          <Link to={"/seach"} className="text-slate-700 hover:underline">
            <li>Tìm Tài Khoản</li>
          </Link>
        </ul>
      </div>
    </header>
  );
};

export default Header;



