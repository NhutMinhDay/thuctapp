import React, { useEffect, useState } from "react";
import axios from "axios";
import FormQr from "./FormQr";
import { Link } from "react-router-dom";
const ListQr = () => {
  const [qrList, setQrList] = useState([]);
  console.log(qrList);
  const [selectedQR, setSelectedQR] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchQrList = async () => {
      try {
        const response = await axios.get("/api/qr_nv");
        setQrList(response.data);
        setLoading(false);
      } catch (err) {
        setError("Đã xảy ra lỗi khi lấy dữ liệu từ server.");
        setLoading(false);
      }
    };

    fetchQrList();
  }, []);

  if (loading) return <div className="flex justify-center">Đang tải...</div>;
  if (error) return <div className="flex justify-center">{error}</div>;

  const handleDelete = async (id) => {
    try {
      await axios.delete(`/api/qr_nv/${id}`);
      setQrList(qrList.filter((state) => state.MA_QR !== id));
      console.log("QR deleted successfully");
    } catch (error) {
      console.error("Error deleting QR:", error);
    }
  };

  const handleUpdate = async (id) => {
    const qrToUpdate = qrList.find((state) => state.MA_QR === id);
    setSelectedQR(qrToUpdate);
  };

  const handleUpdateSuccess = (updatedData) => {
    const updatedQrList = qrList.map((qr) =>
      qr.MA_QR === updatedData.MA_QR ? updatedData : qr
    );
    setQrList(updatedQrList);
    setSelectedQR(null);
  };

  return (
    <div className="pl-36 flex flex-col items-center p-auto">
      <div className="flex justify-between w-full mb-4">
        <h2 className="text-2xl font-bold">Danh Sách Ảnh QR</h2>
        <Link to={"/addqr"}>
          <button className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
            ADD QR
          </button>
        </Link>
      </div>
      <div className=" grid sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {qrList.map((qr) => (
          <div key={qr.MA_QR} className="bg-gray-100 p-4 rounded-lg">
            <span className="text-red-600 font-mono">Mã QR: {qr.MA_QR}</span>
            <img
              src={qr.ANH_QR}
              alt={`QR Code ${qr.MA_QR}`}
              className="w-full h-auto mb-4"
            />
            <div className="flex justify-center">
              <button
                className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-1 px-2 md:py-2 md:px-4 rounded mr-2 md:mr-4"
                onClick={() => handleUpdate(qr.MA_QR)}
              >
                Update
              </button>
              <button
                className="bg-red-500 hover:bg-red-700 text-white font-bold py-1 px-2 md:py-2 md:px-4 rounded"
                onClick={() => handleDelete(qr.MA_QR)}
              >
                Delete
              </button>
            </div>
          </div>
        ))}
      </div>

      {selectedQR && (
        <FormQr entry={selectedQR} onUpdateSuccess={handleUpdateSuccess} />
      )}
    </div>
  );
};

export default ListQr;
