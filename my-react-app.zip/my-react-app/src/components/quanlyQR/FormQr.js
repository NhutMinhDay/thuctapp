import React, { useState } from "react";
import axios from "axios";
import { ImagetoBase64 } from "../../utility/ImagetoBase64";

const FormQr = ({ entry }) => {
  const [formData, setFormData] = useState({
    ANH_QR: entry.ANH_QR,
    newImage: "",
  });
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const [showNewImage, setShowNewImage] = useState(false); // Toggle state

  const handleImageChange = async (event) => {
    const file = event.target.files[0];
    if (file) {
      try {
        const base64Image = await ImagetoBase64(file);
        setFormData({
          ...formData,
          newImage: base64Image,
        });
      } catch (error) {
        console.error("Error converting image to base64:", error);
      }
    }
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const updatedData = { ...formData };
      updatedData.ANH_QR = formData.newImage;

      delete updatedData.newImage;

      await axios.put(`/api/qr_nv/${entry.MA_QR}`, updatedData);
      console.log("Update QR successful");
      setSuccess(true);
      window.location.reload(); // Reload trang sau khi thành công
    } catch (error) {
      console.error("Error updating data:", error);
      setError("Đã xảy ra lỗi khi cập nhật dữ liệu.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto p-4">
      <h2 className="text-2xl mb-4">Update Form</h2>
      <label className="block mb-2">
        QR Image:
        <img
          src={showNewImage ? formData.newImage : formData.ANH_QR}
          alt="QR Code"
          className="block w-48 h-48 mt-2"
        />
      </label>
      <br />
      {error && <div className="text-red-500 mb-2">{error}</div>}
      {success && <div className="text-green-500 mb-2">Cập nhật thành công!</div>}
      <form onSubmit={handleSubmit} className="max-w-sm">
        <label className="block mb-2">
          New Image:
          <input
            type="file"
            accept="image/*"
            name="newImage"
            onChange={handleImageChange}
            className="mt-2"
          />
        </label>
        <br />
        <button
          type="button" // Change type to button
          onClick={() => setShowNewImage(!showNewImage)} // Toggle the state
          className="bg-blue-500 text-white py-2 px-4 rounded mr-2"
        >
          {showNewImage ? "Show Old Image" : "Show New Image"}
        </button>
        <button
          type="submit"
          disabled={loading}
          className="bg-blue-500 text-white py-2 px-4 rounded"
        >
          {loading ? "Đang cập nhật..." : "Update"}
        </button>
      </form>
    </div>
  );
};

export default FormQr;
