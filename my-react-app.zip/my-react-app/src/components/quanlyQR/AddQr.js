// import React, { useState } from 'react';
// import axios from 'axios';
// import { ImagetoBase64 } from '../../utility/ImagetoBase64';
// import { useNavigate } from 'react-router-dom';

// const AddQr = () => {
//   const [file, setFile] = useState(null);
//   const [error, setError] = useState('');
//   const navigate = useNavigate();

//   const handleFileChange = (e) => {
//     setFile(e.target.files[0]);
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     if (!file) {
//       setError('Vui lòng chọn một file.');
//       return;
//     }

//     try {
//       const base64Image = await ImagetoBase64(file);
//       await axios.post('/api/qr_nv', { ANH_QR: base64Image });
//       navigate('/listqr');
//     } catch (err) {
//       setError('Đã xảy ra lỗi khi tải ảnh lên.');
//       console.error(err);
//     }
//   };

//   return (
//     <div className="flex justify-center">
//       <h2>Thêm Ảnh QR</h2>
//       <form onSubmit={handleSubmit}>
//         <input type="file" accept="image/*" onChange={handleFileChange} />
//         <button type="submit">Thêm</button>
//       </form>
//       {error && <p style={{ color: 'red' }}>{error}</p>}
//     </div>
//   );
// };

// export default AddQr;

import React, { useState } from "react";
import axios from "axios";
import { ImagetoBase64 } from "../../utility/ImagetoBase64";
import { useNavigate } from "react-router-dom";










const AddQr = () => {
  const [file, setFile] = useState(null);
  const [previewImage, setPreviewImage] = useState(null); // State for preview image
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    setFile(selectedFile);

    // Preview selected image
    if (selectedFile) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewImage(reader.result);
      };
      reader.readAsDataURL(selectedFile);
    } else {
      setPreviewImage(null);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!file) {
      setError("Vui lòng chọn một file.");
      return;
    }

    try {
      const base64Image = await ImagetoBase64(file);
      await axios.post("/api/qr_nv", { ANH_QR: base64Image });
      navigate("/listqr");
    } catch (err) {
      setError("Đã xảy ra lỗi khi tải ảnh lên.");
      console.error(err);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center h-screen">
      <h2 className="text-2xl font-semibold mb-4">Thêm Ảnh QR</h2>
      <form onSubmit={handleSubmit} className="max-w-md border bg-slate-300 p-8 rounded-lg">
        {/* xem lại ảnh */}
        {previewImage && (
          <img
            src={previewImage}
            alt="Preview"
            className="mb-4 max-w-full rounded h-auto"
          />
        )}
        <input
          type="file"
          accept="image/*"
          onChange={handleFileChange}
          className="mb-4"
        />
        <button
          type="submit"
          className="bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600 transition-colors"
        >
          Thêm
        </button>
      </form>
      {error && <p className="text-red-500">{error}</p>}
    </div>
  );
};

export default AddQr;
