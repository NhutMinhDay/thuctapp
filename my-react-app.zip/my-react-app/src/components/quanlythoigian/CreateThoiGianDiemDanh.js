// components/quanlithoigian/CreateThoiGianDiemDanh.js
import React, { useState } from "react";
import axios from "axios";

const CreateThoiGianDiemDanh = () => {
  const [formData, setFormData] = useState({
    DD_SANGDAU: "",
    DD_SANGCUOI: "",
    DD_CHIEUDAU: "",
    DD_CHIEUCUOI: "",
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };
  console.log(formData);
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post("/api/thoigian_diemdanh", formData);
      console.log("Create successfully");
      // Đặt lại formData thành một đối tượng rỗng
      setFormData({
        DD_SANGDAU: "",
        DD_SANGCUOI: "",
        DD_CHIEUDAU: "",
        DD_CHIEUCUOI: "",
      });
    } catch (error) {
      console.error("Error creating entry:", error);
    }
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="flex justify-center space-x-3 my-2"
    >
      <div className="flex flex-col">
        <label htmlFor="DD_SANGDAU">Đầu Sáng:</label>
        <input
          className="border border-gray-300 rounded-md px-3 py-2"
          type="datetime-local"
          id="DD_SANGDAU"
          name="DD_SANGDAU"
          value={formData.DD_SANGDAU}
          onChange={handleChange}
        />
      </div>
      <div className="flex flex-col">
        <label htmlFor="DD_SANGCUOI">Cuối Sáng:</label>
        <input
          className="border border-gray-300 rounded-md px-3 py-2"
          type="datetime-local"
          id="DD_SANGCUOI"
          name="DD_SANGCUOI"
          value={formData.DD_SANGCUOI}
          onChange={handleChange}
        />
      </div>
      <div className="flex flex-col">
        <label htmlFor="DD_CHIEUDAU">Đầu Chiều:</label>
        <input
          className="border border-gray-300 rounded-md px-3 py-2"
          type="datetime-local"
          id="DD_CHIEUDAU"
          name="DD_CHIEUDAU"
          value={formData.DD_CHIEUDAU}
          onChange={handleChange}
        />
      </div>
      <div className="flex flex-col">
        <label htmlFor="DD_CHIEUCUOI">Cuối Chiều:</label>
        <input
          className="border border-gray-300 rounded-md px-3 py-2"
          type="datetime-local"
          id="DD_CHIEUCUOI"
          name="DD_CHIEUCUOI"
          value={formData.DD_CHIEUCUOI}
          onChange={handleChange}
        />
      </div>
      <button
        className="bg-blue-500 hover:bg-blue-700 text-white font-bold  px-4 rounded"
        type="submit"
      >
        Create
      </button>
    </form>
  );
};

export default CreateThoiGianDiemDanh;
