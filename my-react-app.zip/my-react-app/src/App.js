import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Header from "./components/Hearder";
import CreateThoiGianDiemDanh from "./components/quanlythoigian/CreateThoiGianDiemDanh";
import ThoiGianDiemDanhList from "./components/quanlythoigian/ThoiGianDiemDanhList";
import UpdateForm from "./components/quanlythoigian/UpdateForm";
import AddQr from "./components/quanlyQR/AddQr";
import ListQr from "./components/quanlyQR/ListQr";
import FormQr from "./components/quanlyQR/FormQr";
import AddImagenv from "./components/QuanLyimage_nv/AddImagenv";
import ListImagenv from "./components/QuanLyimage_nv/ListImagenv";
import FormImage from "./components/QuanLyimage_nv/FormImage";

function App() {
  return (
    <BrowserRouter>
      <div className="flex flex-col sm:flex-row">
        <Header />
        <main className="flex-1 m-4 p-2">
          <Routes>
            <Route path="/create" element={<CreateThoiGianDiemDanh />} />
            <Route path="/list" element={<ThoiGianDiemDanhList />} />
            <Route path="/update/:id" element={<UpdateForm />} />

            <Route path="/addqr" element={<AddQr />} />
            <Route path="/listqr" element={<ListQr />} />
            <Route path="/updateqr/:id" element={<FormQr />} />

            <Route path="/addimage" element={<AddImagenv />} />
            <Route path="/listimage" element={<ListImagenv />} />
            <Route path="/updateimage/:id" element={<FormImage />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  );
}

export default App;
